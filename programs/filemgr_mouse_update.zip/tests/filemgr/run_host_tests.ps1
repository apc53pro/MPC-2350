param(
    [string]$Compiler = 'C:\msys64\mingw64\bin\g++.exe',
    [string]$Python = 'python',
    [string]$CodecWorkDir = ''
)
$ErrorActionPreference = 'Stop'
$testRoot = $PSScriptRoot
$source = Join-Path $testRoot 'filemgr_host_tests.cpp'
$binary = Join-Path $testRoot 'filemgr_host_tests.exe'
$previews = Join-Path $testRoot 'previews'
& $Compiler -std=c++17 -O2 -Wall -Wextra -Wno-unused-variable -Wno-unused-parameter -Wno-write-strings $source -o $binary
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR host harness compilation failed' }
& $binary $previews
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR behavioral regression failed' }


$imageSource = Join-Path $testRoot 'test_filemgr_image_streaming.cpp'
$imageBinary = Join-Path $testRoot 'filemgr_image_tests.exe'
& $Compiler -std=c++17 -O2 -Wall -Wextra -Wno-unused-variable -Wno-unused-parameter -Wno-write-strings $imageSource -o $imageBinary
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR image streaming harness compilation failed' }
& $imageBinary
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR image streaming regression failed' }

$codecDriver = Join-Path $testRoot 'filemgr_codec_host_tests.exe'
$codecRuntime = Join-Path $testRoot 'filemgr_codec_runtime_tests.exe'
& $Compiler -std=c++17 -O2 -w (Join-Path $testRoot 'filemgr_codec_host_driver.cpp') -o $codecDriver
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR codec driver compilation failed' }
& $Compiler -std=c++17 -O2 -w (Join-Path $testRoot 'test_filemgr_codec_runtime.cpp') -o $codecRuntime
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR codec runtime compilation failed' }
$codecArgs = @((Join-Path $testRoot 'test_filemgr_codecs.py'), '--driver', $codecDriver, '--runtime-driver', $codecRuntime)
if ($CodecWorkDir) { $codecArgs += @('--workdir', $CodecWorkDir) }
& $Python @codecArgs
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR PNG/JPEG regressions failed' }

$mouseBinary = Join-Path $testRoot 'filemgr_mouse_tests.exe'
& $Compiler -std=c++17 -O2 -w (Join-Path $testRoot 'test_filemgr_mouse.cpp') -o $mouseBinary
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR mouse harness compilation failed' }
& $mouseBinary $previews
if ($LASTEXITCODE -ne 0) { throw 'FILEMGR mouse regressions failed' }
