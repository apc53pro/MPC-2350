"""Execute NARMCC-generated FILEMGR Thumb code against a deterministic VGA4 mock.

Unlike the C++ host harness, these tests exercise NARMCC call resolution, argument
passing, generated instructions, image loading and relocations. Firmware video
callbacks are mocked at the ABI boundary; this is not an RP2350/VGA hardware test.
The legacy-name fixture deliberately reproduces the builtin/helper collision that
sent clears to the independent half-resolution buffer while glyphs used VGA4.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
dependency_parser = argparse.ArgumentParser(add_help=False)
dependency_parser.add_argument("--deps", type=Path)
dependency_args, _ = dependency_parser.parse_known_args()
if dependency_args.deps:
    sys.path.insert(0, str(dependency_args.deps.resolve()))
else:
    for ancestor in ROOT.parents:
        candidate = ancestor / "narm_scheduler_test_deps"
        if candidate.is_dir():
            sys.path.insert(0, str(candidate))
            break
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_MCLASS, UC_MODE_THUMB, UC_HOOK_CODE
from unicorn import arm_const as arm

TEXT = 0x10000000
DATA = 0x20000000
CONTEXT = 0x21000000
API = CONTEXT + 0x100
VIDEO = CONTEXT + 0x200
STACK = 0x22000000
STUB = 0x30000000
STOP = STUB + 0x100
WIDTH, HEIGHT = 640, 480


def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def signed(value: int) -> int:
    return value if value < 0x80000000 else value - 0x100000000


class NativeVideo:
    def __init__(self, image: bytes):
        assert image[:4] == b"NARM" and struct.unpack_from("<H", image, 4)[0] == 0xA0
        self.uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.uc.ctl_set_cpu_model(arm.UC_CPU_ARM_CORTEX_M33)
        self.uc.mem_map(TEXT, 0x100000)
        self.uc.mem_map(DATA, 0x100000)
        self.uc.mem_map(CONTEXT, 0x1000)
        self.uc.mem_map(STACK, 0x40000)
        self.uc.mem_map(STUB, 0x1000)
        text_start, text_size = u32(image, 0x1C), u32(image, 0x20)
        data_start, data_size = u32(image, 0x34), u32(image, 0x38)
        assert u32(image, 0x2C) == 0, "update test loader for separate rodata"
        self.uc.mem_write(TEXT, image[text_start:text_start + text_size])
        self.uc.mem_write(DATA, image[data_start:data_start + data_size])
        reloc_start, reloc_count = u32(image, 0x50), u32(image, 0x54)
        for index in range(reloc_count):
            patch, addend, kind, reserved = struct.unpack_from("<IIHH", image, reloc_start + index * 12)
            assert reserved == 0
            if kind == 0:
                continue
            address = {1: DATA, 2: TEXT, 3: TEXT, 4: CONTEXT}[kind] + addend
            if kind == 3:
                address |= 1
            self.write32(DATA + patch, address)
        self.write32(CONTEXT, 68)
        self.write32(CONTEXT + 8, API)
        self.write32(CONTEXT + 16, TEXT)
        self.write32(CONTEXT + 20, text_size)
        self.write32(CONTEXT + 24, DATA)
        self.write32(CONTEXT + 28, data_size + u32(image, 0x40))
        self.write32(CONTEXT + 56, VIDEO)
        self.write32(API, 32)
        self.write32(API + 16, STUB + 1)  # NativeApiV1::invoke
        self.write32(API + 20, STUB + 1)  # safepoint yield (disabled by null flag)
        self.write32(VIDEO, 32)
        for offset, address in ((8, STUB + 0x10), (12, STUB + 0x20),
                                (16, STUB + 0x30), (20, STUB + 0x40),
                                (24, STUB + 0x50), (28, STUB + 0x60)):
            self.write32(VIDEO + offset, address | 1)
        self.uc.mem_write(STUB, b"\x70\x47" * 0x800)  # bx lr callback stubs
        self.uc.reg_write(arm.UC_ARM_REG_R0, CONTEXT)
        self.uc.reg_write(arm.UC_ARM_REG_R9, DATA)
        self.uc.reg_write(arm.UC_ARM_REG_R10, CONTEXT)
        self.uc.reg_write(arm.UC_ARM_REG_SP, STACK + 0x3FFF0)
        self.uc.reg_write(arm.UC_ARM_REG_LR, STOP | 1)
        self.uc.hook_add(UC_HOOK_CODE, self.callback, begin=STUB, end=STUB + 0xFFF)
        self.entry = TEXT + u32(image, 0x18)
        self.pixels = bytearray([7]) * (WIDTH * HEIGHT)
        self.snapshots: list[bytes] = []
        self.rect_calls: list[tuple[int, ...]] = []
        self.graphics_commands: list[int] = []
        self.finished = False

    def write32(self, address: int, value: int) -> None:
        self.uc.mem_write(address, struct.pack("<I", value))

    def words(self, address: int, count: int) -> tuple[int, ...]:
        return struct.unpack("<" + "I" * count, self.uc.mem_read(address, count * 4))

    def pixel(self, x: int, y: int, color: int) -> None:
        if 0 <= x < WIDTH and 0 <= y < HEIGHT:
            self.pixels[y * WIDTH + x] = color & 15

    def rectangle(self, values: tuple[int, ...]) -> None:
        x0, y0, x1, y1 = map(signed, values[:4])
        for y in range(max(0, y0), min(HEIGHT - 1, y1) + 1):
            begin, end = max(0, x0), min(WIDTH - 1, x1)
            if begin <= end:
                self.pixels[y * WIDTH + begin:y * WIDTH + end + 1] = bytes([values[4] & 15]) * (end - begin + 1)

    def line(self, values: tuple[int, ...]) -> None:
        x0, y0, x1, y1 = map(signed, values[:4])
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        error = dx + dy
        while True:
            self.pixel(x0, y0, values[4])
            if x0 == x1 and y0 == y1:
                break
            doubled = 2 * error
            if doubled >= dy:
                error += dy
                x0 += sx
            if doubled <= dx:
                error += dx
                y0 += sy

    def callback(self, uc: Uc, address: int, size: int, _: object) -> None:
        del size
        if address == STOP:
            self.finished = True
            uc.emu_stop()
            return
        r1 = uc.reg_read(arm.UC_ARM_REG_R1)
        if address == STUB:
            assert r1 == 0, f"unexpected general firmware service {r1:#x}"
            self.snapshots.append(bytes(self.pixels))
        elif address == STUB + 0x10:
            self.pixels[:] = bytes([self.words(r1, 1)[0] & 15]) * len(self.pixels)
        elif address == STUB + 0x20:
            x, y, color = self.words(r1, 3)
            self.pixel(signed(x), signed(y), color)
        elif address == STUB + 0x30:
            values = self.words(r1, 5)
            self.rect_calls.append(values)
            self.rectangle(values)
        elif address == STUB + 0x40:
            self.line(self.words(r1, 5))
        elif address == STUB + 0x50:
            pass  # Present does not change the shared framebuffer.
        elif address == STUB + 0x60:
            self.graphics_commands.append(r1)
            pointer, count = uc.reg_read(arm.UC_ARM_REG_R2), uc.reg_read(arm.UC_ARM_REG_R3)
            if r1 == 3:
                assert count == 5  # legacy HALF_FILL_RECT: not the VGA4 surface
            else:
                assert r1 == 0x100 and count == 6, f"unexpected graphics command {r1:#x}"
                x, y, width, height, bits, color = self.words(pointer, count)
                glyph = self.words(bits, (width * height + 31) // 32)
                for py in range(height):
                    for px in range(width):
                        bit = py * width + px
                        if glyph[bit // 32] & (1 << (31 - bit % 32)):
                            self.pixel(signed(x) + px, signed(y) + py, color)
        else:
            raise AssertionError(f"unexpected ABI callback {address:#x}")
        uc.reg_write(arm.UC_ARM_REG_R0, 0)

    def run(self) -> None:
        self.uc.emu_start(self.entry | 1, STOP + 2, count=120_000_000)
        assert self.finished, "native test did not return within instruction budget"
        assert self.uc.reg_read(arm.UC_ARM_REG_R0) == 0, "native fixture returned an error"


FIXTURE = r'''
#define main filemgr_original_main
#include "filemgr640.tc"
#undef main

void regressionCopy(char destination[], char source[])
{
    int i = 0;
    while (source[i] != 0) { destination[i] = source[i]; i = i + 1; }
    destination[i] = 0;
}

int main()
{
    cwd[0] = '/'; cwd[1] = 0;
    activeStorage = 1; mode = 0; scanDone = 1; scanActive = 0;
    entryCount = 2; cacheStart = 0; selectedIndex = 0; scrollIndex = 0;
    cacheStatuses[0] = 1; cacheStatuses[1] = 1;
    cacheTypes[0] = 0; cacheTypes[1] = 0;
    regressionCopy(&cacheNames[0], "A VERY LONG FIRST FILE NAME.TXT");
    regressionCopy(&cacheNames[48], "B.TXT");
    cacheLens[0] = 31; cacheLens[1] = 5;
    selectedInfoValid = 1; selectedType = 0; selectedSize = 1234567;
    regressionCopy(selectedDisplayName, "A VERY LONG FIRST FILE NAME.TXT");
    audioLoaded = 1; audioPlaying = 1; audioPaused = 0; audioStopped = 0;
    audioSampleRate = 48000; audioTotalFrames = 48000 * 180;
    audioCurrentFrame = 48000 * 150;
    regressionCopy(audioName, "A VERY LONG AUDIO TRACK NAME.WAV");
    renderBrowser(); narm_yield();

    selectedIndex = 1; selectedSize = 2;
    regressionCopy(selectedDisplayName, "B.TXT");
    quickOldSlot = 0; quickNewSlot = 1;
    renderBrowserQuickMove(); narm_yield();
    renderBrowser(); narm_yield();

    mode = 2; createMode = 1;
    regressionCopy(editName, "A VERY LONG NAME TO ERASE.TXT"); editLen = 28;
    renderNameEdit(); narm_yield();
    regressionCopy(editName, "B.TXT"); editLen = 5;
    renderNameEditQuick(); narm_yield();
    renderNameEdit(); narm_yield();

    audioPlaying = 0; audioPaused = 0; audioStopped = 1;
    audioCurrentFrame = 0; audioTotalFrames = 48000 * 9;
    regressionCopy(audioName, "B.WAV");
    renderAudioPanel(); narm_yield();
    renderNameEdit(); narm_yield();

    confirmDelete = 1; statusCode = 3;
    drawStatus(); narm_yield();
    confirmDelete = 0; statusCode = 0;
    drawStatus(); narm_yield();
    renderNameEdit(); narm_yield();
    return 0;
}
'''


def compile_source(compiler: Path, source: Path, include: Path, output: Path, level: int) -> bytes:
    result = subprocess.run([str(compiler), str(source), "-I", str(include), f"-O{level}",
                             "--stack-bytes", "32768", "-o", str(output)], text=True, capture_output=True)
    if result.returncode:
        raise AssertionError(f"NARMCC failed:\n{result.stdout}\n{result.stderr}")
    return output.read_bytes()


def compare(actual: bytes, expected: bytes, name: str) -> None:
    different = [index for index, (a, b) in enumerate(zip(actual, expected)) if a != b]
    if different:
        xs = [index % WIDTH for index in different]
        ys = [index // WIDTH for index in different]
        raise AssertionError(f"{name}: {len(different)} stale/different pixels in "
                             f"({min(xs)},{min(ys)})-({max(xs)},{max(ys)})")


def main() -> None:
    default_app = ROOT.parent / "app"
    default_compiler = ROOT.parent / "compiler" / "narmcc.exe"
    if not (default_app / "filemgr640.tc").is_file():
        default_app = ROOT.parents[1] / "MPC-2350_Firmware" / "programs" / "filemgr"
        default_compiler = ROOT.parents[1] / "Compiler_For_NARM" / "narmcc.exe"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deps", type=Path, help="directory containing the unicorn Python package")
    parser.add_argument("--compiler", type=Path, default=default_compiler)
    parser.add_argument("--app", type=Path, default=default_app)
    args = parser.parse_args()
    app = args.app.resolve()
    compiler = args.compiler.resolve()
    with tempfile.TemporaryDirectory(prefix="filemgr_native_graphics_") as directory:
        temporary = Path(directory)
        source = temporary / "fixture.tc"
        source.write_text(FIXTURE, encoding="utf-8")
        for level in (0, 3):
            machine = NativeVideo(compile_source(compiler, source, app, temporary / "app.narm", level))
            machine.run()
            assert len(machine.snapshots) == 11
            assert 3 not in machine.graphics_commands, "FILEMGR clear reached half-resolution buffer"
            compare(machine.snapshots[1], machine.snapshots[2], f"O{level} selection/detail repaint")
            compare(machine.snapshots[4], machine.snapshots[5], f"O{level} shortened name repaint")
            compare(machine.snapshots[6], machine.snapshots[7], f"O{level} audio track/progress repaint")
            compare(machine.snapshots[9], machine.snapshots[10], f"O{level} status confirmation cleanup")
            print(f"PASS O{level}: compiled Thumb selection, name, audio and status redraws match full frames")

        graphics = (app / "filemgr_graphics.tch").read_text(encoding="utf-8")
        assert "void fmFillRect(" in graphics, "FILEMGR helper must avoid legacy builtin name"
        prefix = '#include "narm.tch"\nint SCREEN_W=640; int SCREEN_H=480; uint fontLo[64]; uint fontHi[64];\n'
        for legacy in (True, False):
            name = "fillRect2D" if legacy else "fmFillRect"
            fixture_graphics = graphics.replace("fmFillRect", "fillRect2D") if legacy else graphics
            source.write_text(prefix + fixture_graphics + "\nint main() { narm_clear(1); " +
                              name + "(11, 12, 29, 30, 6); narm_yield(); return 0; }\n", encoding="utf-8")
            machine = NativeVideo(compile_source(compiler, source, app, temporary / "helper.narm", 3))
            machine.run()
            if legacy:
                assert machine.graphics_commands == [3] and not machine.rect_calls
                assert machine.snapshots[0][20 * WIDTH + 20] == 1
                print("PASS regression reproduction: legacy fillRect2D silently targets HALF_FILL_RECT")
            else:
                assert machine.rect_calls == [(11, 12, 29, 30, 6)] and not machine.graphics_commands
                assert machine.snapshots[0][20 * WIDTH + 20] == 6
                print("PASS fix: actual fmFillRect helper targets the VGA4 rectangle ABI")
    print("All native FILEMGR graphics regression checks passed (mock firmware video, not physical VGA).")


if __name__ == "__main__":
    main()
