#include <cstdio>
#include <cstdlib>
#include <jpeglib.h>
int main(int argc,char**argv){
 if(argc!=2)return 1;
 FILE* out=fopen(argv[1],"wb");if(!out)return 2;
 jpeg_compress_struct c{};jpeg_error_mgr e{};c.err=jpeg_std_error(&e);jpeg_create_compress(&c);jpeg_stdio_dest(&c,out);
 c.image_width=17;c.image_height=13;c.input_components=4;c.in_color_space=JCS_CMYK;
 jpeg_set_defaults(&c);jpeg_set_colorspace(&c,JCS_YCCK);jpeg_set_quality(&c,93,TRUE);jpeg_simple_progression(&c);jpeg_start_compress(&c,TRUE);
 unsigned char row[17*4];
 while(c.next_scanline<c.image_height){int y=c.next_scanline;for(int x=0;x<17;++x){row[x*4]=(x*29+y*7)%256;row[x*4+1]=(x*13+y*31)%256;row[x*4+2]=(x*17+y*11)%256;row[x*4+3]=(x*41+y*19)%256;}JSAMPROW rows[]={row};jpeg_write_scanlines(&c,rows,1);}
 jpeg_finish_compress(&c);jpeg_destroy_compress(&c);fclose(out);
}
