"""Execute PNG/JPEG decoding and warm navigation as actual Cortex-M33 Thumb code.

Uses Pillow for fixtures and the host decoder as a packed-pixel oracle. The host
reference suite separately compares RGB against PNG inputs and libjpeg.
"""
from pathlib import Path
import argparse,subprocess,struct,tempfile
from PIL import Image
from test_filemgr_native_graphics import compile_source,arm
from test_filemgr_native_images import ImageMachine,FIXTURE,trunc_div
from test_filemgr_codecs import make_png
ROOT=Path(__file__).resolve().parent
class Machine(ImageMachine):
 def __init__(self,image,sample):
  super().__init__(image,sample)
  self.uc.mem_map(0xE000E000,0x2000);self.write32(0xE000ED88,0x00F00000)

def verify(machine,expected,w,h):
 actual=bytes(machine.files['/.fm_img.tmp']);assert actual==expected,('native cache differs',sum(a!=b for a,b in zip(actual,expected)),len(actual),len(expected))
 assert '/.fm_jpeg.tmp' not in machine.files,'JPEG coefficients must be removed'
 stride=(w+1)//2;scale=min(640*256//w,298*256//h);cx,cy=w//2,h//2
 states=[(scale,cx,cy)];cx=min(w-1,cx+max(1,4096//scale));scale=min(scale,16384);states.append((scale,cx,cy))
 scale=min(16384,scale*5//4);states.append((scale,cx,cy));cy=min(h-1,cy+max(1,4096//scale));states.append((scale,cx,cy));states.append((min(640*256//w,298*256//h),w//2,h//2))
 for pixels,(scale,cx,cy) in zip(machine.snapshots,states):
  for y in range(70,368):
   sy=cy+trunc_div((y-219)*256,scale)
   for x in range(640):
    sx=cx+trunc_div((x-320)*256,scale);color=1
    if 0<=sx<w and 0<=sy<h:color=(expected[512+sy*stride+sx//2]>>(4 if sx%2==0 else 0))&15
    assert pixels[y*640+x]==color,('viewport',x,y,pixels[y*640+x],color)
 # Source decoding has finished before the first yield. Navigation must use only the packed source blocks.
 reads=[r for r in machine.reads if r[0]>0];assert not reads,('navigation performed file reads',reads[:5])


def run(args,TMP):
    APP=args.app.resolve();COMPILER=args.compiler.resolve();DRIVER=args.driver.resolve()
    cases=[]
    for name,depth,kind,interlace,method in [('rgba_adam7',8,6,True,'dynamic'),('rgb16',16,2,False,'stored'),('indexed2',2,3,True,'fixed')]:
     data,_=make_png(17,13,depth,kind,interlace,method);path=TMP/(name+'.png');path.write_bytes(data);cases.append(path)
    image=Image.new('RGB',(17,13));image.putdata([((x*29+y*7)%256,(x*13+y*31)%256,(x*17+y*11)%256) for y in range(13) for x in range(17)])
    for name,mode,progressive,sub in [('base420','RGB',False,2),('progress422','RGB',True,1),('gray_progress','L',True,0),('cmyk','CMYK',False,0)]:
     path=TMP/(name+'.jpeg');image.convert(mode).save(path,'JPEG',quality=93,subsampling=sub,progressive=progressive);cases.append(path)
    wrapped,_=make_png(83,109,8,6,True,'dynamic');wrapped_path=TMP/'rgba_window_wrap.png';wrapped_path.write_bytes(wrapped);cases.append(wrapped_path)
    large=Image.new('RGB',(65,39));large.putdata([((x*29+y*7)%256,(x*13+y*31)%256,(x*17+y*11)%256) for y in range(39) for x in range(65)])
    large_path=TMP/'progressive_coeff_pages.jpeg';large.save(large_path,'JPEG',quality=93,subsampling=0,progressive=True);cases.append(large_path)
    ycck=TMP/'progressive_ycck.jpeg';ycck.write_bytes((ROOT/'fixtures/progressive_ycck.jpeg').read_bytes());cases.append(ycck)
    source=TMP/'fixture.tc';source.write_text(FIXTURE)
    for level in (0,3):
     binary=compile_source(COMPILER,source,APP,TMP/f'fixture_O{level}.narm',level)
     assert struct.unpack_from('<HH',binary,0x60)[1]<=13
     for path in cases:
      cache=path.with_suffix('.cache');subprocess.run([str(DRIVER),str(path),str(cache)],check=True,capture_output=True)
      machine=Machine(binary,path.read_bytes())
      try:machine.run()
      except Exception:
       print('FAIL case',path.name,'level',level,'frames',len(machine.snapshots),'reads',len(machine.reads),'r0',machine.uc.reg_read(arm.UC_ARM_REG_R0),'pc',hex(machine.uc.reg_read(arm.UC_ARM_REG_PC)),flush=True);raise
      verify(machine,cache.read_bytes(),*Image.open(path).size)
      print(f'PASS O{level}: {path.name}, exact packed output, 5 full viewports, warm navigation and scratch cleanup',flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app',type=Path,default=ROOT.parents[1]/'MPC-2350_Firmware/programs/filemgr')
    parser.add_argument('--compiler',type=Path,default=ROOT.parents[1]/'Compiler_For_NARM/narmcc.exe')
    parser.add_argument('--driver',type=Path,default=ROOT/'filemgr_codec_host_tests.exe')
    parser.add_argument('--deps',type=Path)
    parser.add_argument('--workdir',type=Path)
    args=parser.parse_args()
    if args.workdir:args.workdir.mkdir(parents=True,exist_ok=True);run(args,args.workdir.resolve())
    else:
        with tempfile.TemporaryDirectory(prefix='filemgr_native_codecs_') as directory:run(args,Path(directory))

if __name__=='__main__':main()
