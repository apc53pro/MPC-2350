# FILEMGR host regression and UI previews

Run `./run_host_tests.ps1` with MinGW GCC available. Pass `-Compiler` to use another
C++17 compiler. On Linux, compile `filemgr_host_tests.cpp` with `g++ -std=c++17 -O2`
and run the resulting executable with the preview output directory as its argument.

The harness directly includes the real FILEMGR source and its UI headers. In the
staging layout it uses `../app/filemgr640.tc`; when installed under
`Firmware/tests/filemgr`, it uses
`../../MPC-2350_Firmware/programs/filemgr/filemgr640.tc` automatically (with
the legacy layout retained as a fallback).
Firmware storage, input, clock, process-launch, audio and graphics services
are deterministic mocks. It tests launching a child without replacing FILEMGR,
failed launches, preserving browser state, one-voice playback, progress from mixer
frames, pause/resume/stop/restart, seeking and clamping, file/folder operations,
focus redraw, and clean close handling.

Audio mocks follow the runtime's ownership rules: play claims a voice, only its
owner can stop/pause/query it, a queued mixer command can make position queries
temporarily busy, and a failed replacement can leave a previous owned voice
running until explicitly stopped. Tests also cover preserving another application's
active voice, first-play failure, stopped seeking, signed seek overflow, normalized
keyboard repeat filtering, file-inspector paging and byte-preserving renames.

Four 640x480 BMP previews are rendered by the actual application functions:
`browser-playing.bmp`, `viewer.bmp`, `name-edit.bmp`, and `empty-folder.bmp`.
The mock renderer reproduces firmware glyph bit packing and the exact RGB332
VGA4 palette. It does not redraw or approximate the UI independently.

Dynamic cleanup regressions also compare the real incremental framebuffer with
a clean, complete render of the identical application state. They compare all
307,200 pixels, without masking any regions. Covered transitions include long
and short filenames, different file types, both selection directions, dismissing
delete confirmation, changing timer digits, backward audio seeking, pause,
resume, stop, completion, track replacement, deleting and inserting name-editor
characters, return from another application's framebuffer, and partially loaded
or scrolled directory caches. Focus tests include an immediate keypress before
the required complete repaint. Directory tests reproduce the main loop's real
order, where storage can leave a full redraw pending before the next keypress.
Ordinary selection, name editing, progress polling and successful seeking also
assert that they do not unnecessarily clear the entire framebuffer. On mismatch,
the error reports the pixel count and bounding rectangle, and saves matching
`cleanup-N-actual.bmp` / `cleanup-N-expected.bmp` snapshots for inspection.

These C++ host tests resolve application functions normally. They do not by
themselves detect a collision between a C helper name and a NARMCC builtin;
generated ARM drawing calls must also be checked separately.

`python test_filemgr_native_graphics.py --deps path/to/unicorn-package-directory`
compiles a fixture that includes the actual FILEMGR source and executes its
generated Thumb instructions using Unicorn. It compares selection/details,
shortened names, audio replacement/progress, and status cleanup against full
renders at both `-O0` and `-O3`. It also reproduces the legacy `fillRect2D` name
collision and asserts that the real `fmFillRect` helper instead calls the VGA4
rectangle ABI. App/compiler paths are detected for staging or project layout;
override them with `--app` and `--compiler` if needed. If Unicorn is already
installed in your Python environment, omit `--deps`. Firmware graphics callbacks
are mocks: these checks execute real compiled program instructions but are not
physical VGA or RP2350 interrupt-timing tests.

The harness validates application behavior and layout. Hardware audio timing,
PS/2 transport, scheduler behavior and physical VGA output still require board
testing. The regular NARMCC compiler build validates the ARM binary separately.

`python test_filemgr_runtime_contracts.py --compiler path/to/g++` additionally
executes extracted firmware spawn-completion, process-finish, command-queue and
audio-snapshot function bodies using host fixtures. It checks child results,
parent focus restoration, failed loads, stale process IDs, queued-command
acknowledgements, seek position/length and pause/stop metadata. Separately labeled
static checks cover loader/context-switch ordering and voice ownership guards.
These checks do not claim to emulate complete firmware or hardware timing.


## Image streaming regressions

`run_host_tests.ps1` also compiles and executes
`test_filemgr_image_streaming.cpp`. It uses the real app and instrumented storage
mocks to verify all packed source pixels and every viewport pixel after fit,
pan, zoom and return. Cases include 24-bit bottom-up BMP, top-down 32-bit BMP,
odd widths, BMP row padding, a 4097-pixel-wide image, 641x481 images larger than
the block cache, PPM P6, PGM P5, Flash and SD. It checks retained blocks, bounded
non-overlapping reads, short reads/writes, cancellation, palette index 14,
cache cleanup, and absence of a delayed duplicate redraw.

`python test_filemgr_native_images.py --deps path/to/unicorn-package-directory`
executes real NARMCC Thumb instructions at both O0 and O3. It verifies the packed
cache and five complete viewports for bottom-up 24-bit and top-down 32-bit BMPs,
including odd widths and 4 KiB boundaries. The tests assert that pan and zoom
reuse source blocks and that the generated program needs no API newer than 1.13.
As with the existing native graphics tests, `--app` and `--compiler` can override
the source and compiler paths. These are deterministic correctness/I/O checks;
they do not measure physical RP2350 frame time or SD latency.


## PNG/JPEG decoder regressions

The host runner now builds `filemgr_codec_host_driver.cpp` and
`test_filemgr_codec_runtime.cpp`, then runs `test_filemgr_codecs.py`. In addition
to MinGW C++, these tests need Python 3, Pillow, and libjpeg `cjpeg`/`djpeg` on
PATH (or pass their paths to the Python suite). `-Python` chooses Python and
`-CodecWorkDir` optionally retains generated fixtures in an explicit directory.
Production FILEMGR has none of those host-library dependencies.

The reference suite covers 92 PNG fixtures (all standard color/depth combinations,
Adam7, all filters, three DEFLATE block types, split IDAT, transparency and 32 KiB
history wrap) and 102 JPEG fixtures (sequential/progressive, sampling, grayscale,
CMYK/YCCK, restarts, component scans, RGB, quantization and large metadata).
Every output PNG palette pixel is checked against independent source pixels.
JPEG RGB is compared with libjpeg's floating IDCT/no-smoothing output, or Pillow
for CMYK/YCCK, allowing only small IDCT rounding differences. A test-only macro
captures RGB; that full-image RGB buffer is absent from the production app.
Malformed/truncated data, CRC/Adler, unsupported variants and the PNG row bound
are tested. Runtime tests cover cancellation during each stage, extension case
handling, and source/output/coefficient read/write failures.

`python test_filemgr_native_codecs.py --deps path/to/unicorn-package-directory`
executes the actual generated Thumb code on Unicorn's Cortex-M33 with its FPU
enabled, at O0 and O3. Pass `--driver` for the compiled host driver; `--app` and
`--compiler` override source/tool paths. Ten PNG/JPEG cases verify exact packed
output, 100 complete viewports, warm navigation and coefficient-file cleanup.
The common native graphics loader now selects the Cortex-M33 explicitly.

`fixtures/progressive_ycck.jpeg` is a generated 17x13 progressive Adobe YCCK test
image. Rebuild it with `g++ fixtures/make_progressive_ycck.cpp -ljpeg -o maker`
and run `maker fixtures/progressive_ycck.jpeg` with libjpeg development files.


## Mouse and context menu regressions

`run_host_tests.ps1` also runs `test_filemgr_mouse.cpp` against the real FILEMGR
source. It checks click/double-click timing, row hit tests, wheel/scrollbar,
context actions and deletion confirmation, stale targets, focus/disconnect/RESYNC,
menu framebuffer restoration, image dragging/zoom, audio and name-editor buttons.
It renders `previews/mouse-context-menu.bmp` through the real UI functions.

`python test_filemgr_native_mouse.py --deps path/to/unicorn-package-directory`
executes actual Thumb calls at O0/O3 through the existing mouse v1.0 interface:
get_interface(0x0101,1,0), state/event calls and cursor/relative-mode callbacks.
It checks click selection, double click, menu hover and deletion cancellation,
resync, wheel scroll, image drag/zoom and complete framebuffer comparisons.
Default app/compiler paths follow the current MPC-2350_Firmware layout; override
`--app`/`--compiler` as needed. `--workdir` retains generated native fixtures.
Tests use mocked firmware mouse/video/storage, not physical PS/2 hardware.
The mouse-enabled build requires the existing firmware API 1.13, while older
non-mouse test fixtures may optimize their imports down to earlier API versions.
