// Compile the actual NARM application against a deterministic host firmware.
// No duplicate application logic is used in these tests or rendered previews.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <deque>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

typedef unsigned uint;
void invalidateImageRowCaches();
void serviceImageCacheBuild();
void drawImageFormatName(int, int, uint);
void render();
void stopAudioPlayback();
void serviceAudio();
int handleSystemEvents();

#define main filemgr_entry
#if __has_include("../app/filemgr640.tc")
#include "../app/filemgr640.tc"
#elif __has_include("../../MPC-2350_Firmware/programs/filemgr/filemgr640.tc")
#include "../../MPC-2350_Firmware/programs/filemgr/filemgr640.tc"
#else
#include "../../resource_development/programs/filemgr/filemgr640.tc"
#endif
#undef main
#undef millis
#undef sin
#undef cos

namespace mock {
std::deque<NarmMouseEvent> mouseEvents;
NarmMouseState mouseState = {320,240,0,NARM_MOUSE_CONNECTED | NARM_MOUSE_FOCUSED};
int cursorCalls = 0;
int relativeCalls = 0;

struct IoRead { std::string path; uint offset, requested, returned; };
std::vector<IoRead> ioReads;
int readLimit = -1;
int writeLimit = -1;
std::string limitedReadPath;

struct Node { bool directory = false; std::vector<unsigned char> bytes; };
std::array<std::map<std::string, Node>, 2> volumes;
std::array<unsigned char, 640 * 480> pixels{};
std::array<bool, 256> keys{};
std::deque<int> events;
std::deque<std::array<uint, 4>> keyEvents;
uint now = 0;
bool focus = true;
int presents = 0;
int clears = 0;
int spawnResult = 17;
int spawnCalls = 0;
int replaceCalls = 0;
std::string spawnedPath;
uint spawnedStorage = 99;
int playResult = 0;
int playCalls = 0;
int stopCalls = 0;
int stopAllCalls = 0;
int pauseCalls = 0;
uint audioVoice = 99;
int audioOwner = -1;
int unownedControlCalls = 0;
bool audioQueryBusy = false;
uint position = 0;
uint total = 48000 * 180;
uint rate = 48000;
uint flags = 0;
std::string playingPath;
std::string normalized(const char *path) {
    std::string value(path);
    if (value.empty() || value[0] != '/') value = "/" + value;
    while (value.size() > 1 && value.back() == '/') value.pop_back();
    return value;
}
Node *node(const char *path, uint storage) {
    if (storage > 1) return nullptr;
    auto it = volumes[storage].find(normalized(path));
    return it == volumes[storage].end() ? nullptr : &it->second;
}
void addFile(const std::string &path, const std::vector<unsigned char> &bytes, uint storage = 1) {
    volumes[storage][normalized(path.c_str())] = {false, bytes};
}
void addText(const std::string &path, const std::string &text, uint storage = 1) {
    addFile(path, std::vector<unsigned char>(text.begin(), text.end()), storage);
}
void addDirectory(const std::string &path, uint storage = 1) {
    volumes[storage][normalized(path.c_str())] = {true, {}};
}
void pixel(int x, int y, uint color) {
    if (x >= 0 && x < 640 && y >= 0 && y < 480) pixels[y * 640 + x] = color & 15;
}
void reset() {
    mouseEvents.clear(); mouseState = {320,240,0,NARM_MOUSE_CONNECTED | NARM_MOUSE_FOCUSED};
    cursorCalls = relativeCalls = 0; fmMenuOpen = fmMenuDirty = fmMouseGesture = 0;
    fmMouseLastRow = -1; fmMouseNeedsInit = 1; fmMenuArmed = -1;

    ioReads.clear(); readLimit = writeLimit = -1; limitedReadPath.clear();
    for (auto &volume : volumes) volume.clear();
    addDirectory("/", 0); addDirectory("/", 1);
    pixels.fill(0); keys.fill(false); events.clear(); keyEvents.clear();
    now = 0; focus = true; presents = clears = 0;
    spawnResult = 17; spawnCalls = replaceCalls = 0;
    spawnedPath.clear(); spawnedStorage = 99;
    playResult = 0; playCalls = stopCalls = stopAllCalls = pauseCalls = 0;
    audioVoice = 99; audioOwner = -1; unownedControlCalls = 0; audioQueryBusy = false;
    position = 0; total = 48000 * 180; rate = 48000; flags = 0;
    playingPath.clear();
}
std::vector<unsigned char> program() {
    std::vector<unsigned char> bytes(256, 0);
    bytes[0] = 'N'; bytes[1] = 'A'; bytes[2] = 'R'; bytes[3] = 'M';
    bytes[4] = 160; bytes[6] = 1; bytes[12] = 1; bytes[14] = 8;
    return bytes;
}
std::vector<unsigned char> wav() {
    std::vector<unsigned char> bytes(44, 0);
    std::memcpy(bytes.data(), "RIFF", 4); std::memcpy(bytes.data() + 8, "WAVE", 4);
    std::memcpy(bytes.data() + 12, "fmt ", 4);
    bytes[16] = 16; bytes[20] = 1; bytes[22] = 2;
    bytes[24] = 0x80; bytes[25] = 0xbb; // 48000 Hz.
    bytes[28] = 0; bytes[29] = 0xee; bytes[30] = 2; // 192000 bytes/s.
    bytes[32] = 4; bytes[34] = 16;
    std::memcpy(bytes.data() + 36, "data", 4);
    return bytes;
}
void bitmap(const std::filesystem::path &path) {
    // Exact drawfuncs.cpp palette; this is not the conventional EGA palette.
    static const unsigned char palette[16] = {255,0,0x02,0x10,0xe0,0x80,0x61,0xec,0xfc,0x1c,0x09,0x9f,0x07,0xe3,0x49,0x92};
    auto expand3 = [](uint v) { return (v << 5) | (v << 2) | (v >> 1); };
    auto expand2 = [](uint v) { return (v << 6) | (v << 4) | (v << 2) | v; };
    std::ofstream out(path, std::ios::binary);
    auto u16 = [&](uint value) { out.put(value & 255); out.put((value >> 8) & 255); };
    auto u32 = [&](uint value) { u16(value & 65535); u16(value >> 16); };
    out.put('B'); out.put('M'); u32(54 + 640 * 480 * 3); u32(0); u32(54);
    u32(40); u32(640); u32(480); u16(1); u16(24); u32(0); u32(640 * 480 * 3);
    u32(2835); u32(2835); u32(0); u32(0);
    for (int y = 479; y >= 0; --y) for (int x = 0; x < 640; ++x) {
        uint rgb = palette[pixels[y * 640 + x] & 15];
        out.put(expand2(rgb & 3)); out.put(expand3((rgb >> 2) & 7)); out.put(expand3(rgb >> 5));
    }
    if (!out) throw std::runtime_error("Failed writing preview " + path.string());
}
}

int narm_yield() { ++mock::now; return 0; }
uint narm_millis() { return mock::now; }
uint narm_micros() { return mock::now * 1000; }
int narm_sleep_ms(uint delay) { mock::now += delay; return 0; }
void narm_exit(int) { throw std::runtime_error("Unexpected application exit"); }
int narm_get_run_mode() { return 0; }
int narm_get_effective_run_mode() { return 1; }
uint narm_get_pid() { return 5; }
int narm_has_focus() { return mock::focus; }
int narm_mouse_get_state(NarmMouseState* state) { *state = mock::mouseState; if (!mock::focus) state->flags &= ~NARM_MOUSE_FOCUSED; return 0; }
int narm_mouse_poll_event(NarmMouseEvent* event) { if(mock::mouseEvents.empty())return 0;*event=mock::mouseEvents.front();mock::mouseEvents.pop_front();mock::mouseState.x=event->x;mock::mouseState.y=event->y;mock::mouseState.buttons=event->buttons;return 1; }
int narm_mouse_set_cursor_visible(uint visible) { ++mock::cursorCalls; return 0; }
int narm_mouse_set_relative_mode(uint relative) { ++mock::relativeCalls; return 0; }
int narm_poll_system_event() {
    if (mock::events.empty()) return 0;
    int event = mock::events.front(); mock::events.pop_front(); return event;
}
int narm_key_down(uint keyId) { return keyId < mock::keys.size() && mock::keys[keyId]; }
int narm_ps2_key_down(uint code, uint) { return narm_key_down(code); }
int narm_next_key_event(uint *keyId, uint *action, uint *mods, uint *character) {
    if (mock::keyEvents.empty()) return 0;
    auto value = mock::keyEvents.front(); mock::keyEvents.pop_front();
    *keyId = value[0]; *action = value[1]; *mods = value[2]; *character = value[3];
    return 1;
}
int narm_spawn_program(const char *path, uint storage) {
    ++mock::spawnCalls; mock::spawnedPath = mock::normalized(path); mock::spawnedStorage = storage;
    return mock::spawnResult;
}
int narm_run_program(const char *, uint) { ++mock::replaceCalls; return -1; }
int narm_storage_mount(uint) { return 1; }
int narm_file_exists(const char *path, uint storage) { return mock::node(path, storage) != nullptr; }
int narm_file_size(const char *path, uint storage, uint *out) {
    auto *node = mock::node(path, storage); if (!node || node->directory) return -1;
    *out = static_cast<uint>(node->bytes.size()); return 0;
}
int narm_file_read(const char *path, void *out, uint offset, uint count, uint storage) {
    auto *node = mock::node(path, storage); if (!node || node->directory) return 0;
    if (offset >= node->bytes.size()) return 0;
    const uint requested = count;
    count = std::min(count, static_cast<uint>(node->bytes.size() - offset));
    if (mock::readLimit >= 0 && mock::normalized(path) == mock::limitedReadPath)
        count = std::min(count, static_cast<uint>(mock::readLimit));
    mock::ioReads.push_back({mock::normalized(path), offset, requested, count});
    std::memcpy(out, node->bytes.data() + offset, count); return count;
}
int narm_file_write(const char *path, const void *data, uint offset, uint count, uint storage) {
    auto *node = mock::node(path, storage); if (!node || node->directory) return 0;
    if (mock::writeLimit >= 0) count = std::min(count, static_cast<uint>(mock::writeLimit));
    if (node->bytes.size() < offset + count) node->bytes.resize(offset + count);
    std::memcpy(node->bytes.data() + offset, data, count); return count;
}
int narm_file_create(const char *path, uint storage) {
    if (mock::node(path, storage)) return 0;
    mock::addFile(path, {}, storage); return 1;
}
int narm_file_delete(const char *path, uint storage) {
    auto *node = mock::node(path, storage); if (!node || node->directory) return 0;
    mock::volumes[storage].erase(mock::normalized(path)); return 1;
}
int narm_file_rename(const char *from, const char *to, uint storage) {
    auto *node = mock::node(from, storage); if (!node || mock::node(to, storage)) return 0;
    mock::volumes[storage][mock::normalized(to)] = *node;
    mock::volumes[storage].erase(mock::normalized(from)); return 1;
}
int narm_dir_make(const char *path, uint storage) {
    if (mock::node(path, storage)) return 0;
    mock::addDirectory(path, storage); return 1;
}
int narm_dir_delete(const char *path, uint storage) {
    auto *node = mock::node(path, storage); if (!node || !node->directory) return 0;
    std::string prefix = mock::normalized(path) + "/";
    for (const auto &entry : mock::volumes[storage]) if (entry.first.find(prefix) == 0) return 0;
    mock::volumes[storage].erase(mock::normalized(path)); return 1;
}
int narm_dir_entry(const char *path, uint index, char *out, uint capacity,
                    uint *length, uint *kind, uint storage) {
    if (storage > 1 || !capacity) return 0;
    std::string prefix = mock::normalized(path); if (prefix != "/") prefix += "/";
    for (const auto &entry : mock::volumes[storage]) {
        if (entry.first == prefix || entry.first.find(prefix) != 0) continue;
        std::string name = entry.first.substr(prefix.size());
        if (name.empty() || name.find('/') != std::string::npos) continue;
        if (index--) continue;
        *length = std::min(static_cast<uint>(name.size()), capacity - 1);
        std::memcpy(out, name.data(), *length); out[*length] = 0;
        *kind = entry.second.directory ? 1 : 0; return 1;
    }
    *length = 0; *kind = 0; out[0] = 0; return 0;
}

uint narm_audio_status() { return 3; }
int narm_audio_ready() { return 1; }
int narm_audio_play_wav_from(uint voice, const char *path, uint frame) {
    ++mock::playCalls; mock::audioVoice = voice;
    if (voice != 0) throw std::runtime_error("FILEMGR touched another audio voice");
    if (mock::audioOwner != -1 && mock::audioOwner != 5 && (mock::flags & 1)) return -5;
    // native_runtime.cpp claims ownership before submitting the play command.
    // Failure can leave a previously playing owned voice active.
    mock::audioOwner = 5;
    if (mock::playResult < 0 || !mock::node(path, 1)) return -1;
    mock::playingPath = mock::normalized(path);
    mock::position = std::min(frame, mock::total); mock::flags = frame < mock::total ? 1 : 0; return 0;
}
int narm_audio_play_wav(uint voice, const char *path) { return narm_audio_play_wav_from(voice, path, 0); }
int narm_audio_stop(uint voice) {
    ++mock::stopCalls; mock::audioVoice = voice;
    if (voice != 0) throw std::runtime_error("FILEMGR stopped another audio voice");
    if (mock::audioOwner != 5) { ++mock::unownedControlCalls; return -5; }
    mock::flags = 0; return 0;
}
int narm_audio_stop_all() { ++mock::stopAllCalls; return 0; }
int narm_audio_active(uint) { return mock::audioOwner == 5 && (mock::flags & 1) != 0; }
int narm_audio_pause(uint voice, uint paused) {
    ++mock::pauseCalls; mock::audioVoice = voice;
    if (voice != 0) throw std::runtime_error("FILEMGR paused another audio voice");
    if (mock::audioOwner != 5) { ++mock::unownedControlCalls; return -5; }
    if (paused) mock::flags |= 2; else mock::flags &= ~2u; return 0;
}
int narm_audio_position(uint voice, uint *current, uint *total, uint *rate, uint *flags) {
    mock::audioVoice = voice;
    if (voice != 0) throw std::runtime_error("FILEMGR queried another audio voice");
    if (mock::audioOwner != 5) { ++mock::unownedControlCalls; return -5; }
    if (mock::audioQueryBusy) return -5;
    *current = mock::position; *total = mock::total; *rate = mock::rate; *flags = mock::flags; return 0;
}
int narm_clear(uint color) { mock::pixels.fill(color & 15); ++mock::clears; return 0; }
int narm_pixel(int x, int y, uint color) { mock::pixel(x, y, color); return 0; }
int narm_fill_rect(int x0, int y0, int x1, int y1, uint color) {
    for (int y = std::max(0, y0); y <= std::min(479, y1); ++y)
        for (int x = std::max(0, x0); x <= std::min(639, x1); ++x) mock::pixel(x, y, color);
    return 0;
}
int narm_line(int x0, int y0, int x1, int y1, uint color) {
    int dx = std::abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -std::abs(y1 - y0), sy = y0 < y1 ? 1 : -1, error = dx + dy;
    while (true) {
        mock::pixel(x0, y0, color); if (x0 == x1 && y0 == y1) break;
        int twice = error * 2;
        if (twice >= dy) { error += dy; x0 += sx; }
        if (twice <= dx) { error += dx; y0 += sy; }
    }
    return 0;
}
int narm_vga4_glyph(int x, int y, int width, int height, const uint *glyph, uint color) {
    for (int row = 0; row < height; ++row) for (int col = 0; col < width; ++col) {
        uint bit = row * width + col;
        if ((glyph[bit >> 5] >> (31 - (bit & 31))) & 1u) mock::pixel(x + col, y + row, color);
    }
    return 0;
}
int narm_present() { ++mock::presents; return 0; }

namespace test {
int checks = 0;
int frameComparisons = 0;
std::filesystem::path frameDirectory;
std::vector<std::string> frameFailures;
void require(bool condition, const std::string &message) {
    ++checks; if (!condition) throw std::runtime_error(message);
}
void text(char *dst, std::size_t capacity, const std::string &src) {
    std::memset(dst, 0, capacity); std::memcpy(dst, src.data(), std::min(capacity - 1, src.size()));
}
void scan() {
    startRefresh();
    for (int i = 0; i < 128 && (cacheLoading || scanActive || selectedInfoDirty); ++i) {
        inputNow = mock::now += 4; serviceSd();
    }
    require(!cacheLoading && !scanActive, "Directory scan must finish");
}
void select(const std::string &name) {
    scan();
    for (int i = 0; i < entryCount; ++i) {
        selectedIndex = i; scrollIndex = 0; requestVisibleCache();
        for (int n = 0; n < 8 && cacheLoading; ++n) serviceVisibleCache();
        if (getSelectedCachedEntry() && name == entryName) {
            selectedInfoDirty = 1; loadSelectedInfo(); return;
        }
    }
    throw std::runtime_error("Cannot select fixture " + name);
}
void setup() {
    mock::reset(); activeStorage = 1; initImagePalette(); initRoot(); initKeys();
    selectedIndex = scrollIndex = mode = statusCode = confirmDelete = 0;
    quickMoveDirty = nameEditQuickDirty = 0;
    audioLoaded = audioPlaying = audioPaused = audioStopped = 0;
    audioCurrentFrame = audioTotalFrames = audioSampleRate = 0;
    audioAwaitingStart = 0; audioNextPollMs = audioStartDeadline = 0;
    audioPanelDirty = 1; text(audioName, sizeof audioName, ""); text(audioPath, sizeof audioPath, "");
    dirty = 1;
}
void launches() {
    setup(); mock::addDirectory("/Applications"); mock::addFile("/Applications/calc640.narm", mock::program());
    text(cwd, sizeof cwd, "/Applications"); select("calc640.narm");
    const std::string before(cwd); const int selectedBefore = selectedIndex;
    openSelected();
    require(mock::spawnCalls == 1 && mock::replaceCalls == 0, "Program launch must spawn and never replace FILEMGR");
    require(mock::spawnedPath == "/Applications/calc640.narm" && mock::spawnedStorage == 1, "Launch must use selected path/storage");
    require(before == cwd && selectedIndex == selectedBefore && mode == 0, "Spawn must preserve browser location and selection");
    mock::spawnResult = -5; statusCode = 0; openSelected();
    require(statusCode != 20 && statusCode != 0, "Failed spawn must report an error instead of launched");
    require(before == cwd && mode == 0, "Failed spawn must preserve FILEMGR");
}
void audio() {
    setup(); mock::addFile("/first.wav", mock::wav()); mock::addFile("/second.wav", mock::wav());
    select("first.wav"); openSelected();
    require(selectedSize == mock::wav().size(), "Browser details must report the actual selected file size");
    require(audioLoaded && audioPlaying && !audioPaused, "Opening WAV must start player");
    require(mock::stopCalls == 0 && mock::unownedControlCalls == 0,
            "First play must claim a voice through play without stopping an unowned voice");
    require(mock::audioVoice == 0 && mock::stopAllCalls == 0, "FILEMGR must only use voice zero");
    require(std::string(audioName) == "first.wav", "Player must remember the loaded audio name");
    mock::audioQueryBusy = true; mock::now += 200; serviceAudio();
    require(audioPlaying && !audioStopped, "Queued mixer command must not be mistaken for completed playback");
    mock::audioQueryBusy = false;
    mock::position = 48000 * 45; mock::now += 1000; serviceAudio();
    require(audioCurrentFrame == mock::position && audioTotalFrames == mock::total && audioSampleRate == 48000, "Player progress must come from mixer frame position");
    toggleAudioPause(); require(audioPaused && (mock::flags & 2), "Space must pause the current voice");
    const uint pausedFrame = mock::position;
    toggleAudioPause(); require(!audioPaused && audioPlaying && mock::position == pausedFrame, "Resume must retain current sample position");
    seekAudioBy(10); require(mock::position == pausedFrame + 48000 * 10, "Seek forwards must use seconds at source sample rate");
    seekAudioBy(-10); require(mock::position == pausedFrame, "Seek backwards must use source frames");
    seekAudioBy(-1000); require(mock::position == 0, "Backward seek must clamp at beginning");
    seekAudioBy(2147483647);
    require(mock::position < mock::total, "Very large forward seek must clamp without multiplication overflow");
    seekAudioBy(-2147483647 - 1);
    require(mock::position == 0, "Minimum signed seek must clamp without signed-negation overflow");
    seekAudioBy(1000); require(audioCurrentFrame <= mock::total && mock::position <= mock::total, "Forward seek must clamp at end");
    audioSeekTo(48000 * 90); require(mock::position == 48000 * 90, "Absolute seek must restart the same audio at requested frame");
    toggleAudioPause(); audioSeekTo(48000 * 30);
    require(audioPaused && (mock::flags & 2), "Seeking paused audio must preserve paused state");
    stopAudioPlayback(); require(!audioPlaying && !audioPaused && audioStopped && !mock::flags, "Stop must release voice and expose stopped state");
    require(audioLoaded, "Stop must retain track so it can be restarted");
    toggleAudioPause(); require(audioPlaying && mock::position == 0, "Play after stop must restart from beginning");
    stopAudioPlayback(); const int playsBeforeStoppedSeek = mock::playCalls;
    audioSeekTo(48000 * 60);
    require(mock::playCalls == playsBeforeStoppedSeek && audioCurrentFrame == 48000 * 60,
            "Seeking stopped audio must move the playhead without starting playback");
    toggleAudioPause(); require(audioPlaying && mock::position == 48000 * 60, "Play after stopped seek must start at the chosen position");
    const int replacementPlays = mock::playCalls;
    select("second.wav"); openSelected();
    require(mock::playCalls > replacementPlays && mock::playingPath == "/second.wav", "Selecting another WAV must replace the existing voice");
    require(mock::audioVoice == 0 && mock::stopAllCalls == 0, "Replacement must never stop other applications' voices");
    mock::position = mock::total; mock::flags = 0; mock::now += 1000; serviceAudio();
    require(!audioPlaying && !audioPaused, "Natural playback completion must update player state");
    require(statusCode == 29 && audioCurrentFrame == audioTotalFrames, "Natural completion must report finished and retain the end playhead");
    toggleAudioPause(); require(audioPlaying && mock::position == 0, "Play after natural end must restart");
    const std::string previousName(audioName), previousPath(audioPath);
    mock::playResult = -1; openSelected();
    require(statusCode == 24 && !audioPlaying && !mock::flags, "Failed playback must report its error and leave no old voice running");
    require(audioLoaded && previousName == audioName && previousPath == audioPath,
            "Failed replacement must keep the previous track available for restart");
    setup(); activeStorage = 0; mock::addFile("/flash.wav", mock::wav(), 0);
    select("flash.wav"); openSelected();
    require(statusCode == 25 && !mock::playCalls, "Unsupported flash WAV playback must explain SD requirement without touching a voice");
    setup(); mock::addFile("/first.wav", mock::wav()); mock::playResult = -1;
    select("first.wav"); openSelected();
    require(statusCode == 24 && !audioLoaded && !mock::flags,
            "First failed play must not expose a phantom loaded track");
    setup(); mock::addFile("/first.wav", mock::wav());
    mock::audioOwner = 19; mock::flags = 1; mock::playingPath = "/other-application.wav";
    select("first.wav"); openSelected();
    require(statusCode == 24 && !audioLoaded && mock::audioOwner == 19 && mock::flags == 1 &&
            mock::playingPath == "/other-application.wav",
            "Busy voice owned by another application must remain untouched when first play fails");
}
void focusAndFiles() {
    setup(); mock::addDirectory("/Music"); select("Music"); openSelected();
    require(std::string(cwd) == "/Music" && mode == 0, "Enter directory must update browser");
    text(editName, sizeof editName, "notes.txt"); editLen = 9; createFileNamed();
    require(mock::node("/Music/notes.txt", 1) != nullptr && mode == 0, "Create file must affect current directory");
    text(editName, sizeof editName, "Samples"); editLen = 7; createDirNamed();
    require(mock::node("/Music/Samples", 1)->directory, "Create folder must affect current directory");
    select("notes.txt"); deleteSelected();
    require(mock::node("/Music/notes.txt", 1) && confirmDelete, "Delete must require confirmation");
    deleteSelected(); require(!mock::node("/Music/notes.txt", 1), "Confirmed delete must remove selected file");
    quickMoveDirty = nameEditQuickDirty = 1; dirty = 0; keyWas[0x5a] = 1;
    mock::events.push_back(NARM_EVENT_FOCUS_LOST); mock::events.push_back(NARM_EVENT_FOCUS_GAINED);
    require(handleSystemEvents() == 1 && dirty && !quickMoveDirty && !nameEditQuickDirty, "Focus gain must force complete redraw over another application's frame");
    require(!keyWas[0x5a], "Focus gain must reset held-key bookkeeping");
    mock::events.push_back(NARM_EVENT_CLOSE_REQUESTED);
    require(handleSystemEvents() == 0, "Close event must request clean application exit");
    goParent(); require(std::string(cwd) == "/", "Back must return to parent");
}
void input() {
    setup(); mock::addFile("/first.wav", mock::wav()); mock::addText("/notes.txt", "Example document\n");
    select("first.wav"); openSelected(); mock::now += 1000; serviceAudio();
    auto press = [](uint keyId, uint action = NARM_KEY_ACTION_PRESS, uint character = 0, uint mods = 0) {
        mock::keyEvents.push_back({keyId, action, mods, character}); updateInput(); applyInput();
    };
    press(NARM_KEY_SPACE); require(audioPaused, "Normalized Space press must pause audio");
    press(NARM_KEY_SPACE, NARM_KEY_ACTION_REPEAT);
    require(audioPaused, "Held Space repeat must not repeatedly toggle playback");
    press(NARM_KEY_SPACE); require(audioPlaying, "Second Space press must resume audio");
    press(NARM_KEY_RIGHT); require(audioCurrentFrame == 48000 * 10, "Right arrow must seek in browser");
    press(NARM_KEY_LEFT); require(audioCurrentFrame == 0, "Left arrow must seek back in browser");
    select("notes.txt"); openSelected(); serviceFileViewLoad();
    press(NARM_KEY_RIGHT);
    require(mode == 1 && audioCurrentFrame == 48000 * 10, "Player seek controls must continue to work in the file inspector");
    press(NARM_KEY_BACKSPACE);
    press(NARM_KEY_P); require(audioStopped, "P must stop audio without closing the browser");
    selectedIndex = 0; press(NARM_KEY_DOWN);
    require(selectedIndex == 1, "Normalized Down event must move browser selection");
    press(NARM_KEY_UP); require(selectedIndex == 0, "Normalized Up event must move browser selection back");
    const int selectedBefore = selectedIndex;
    press(NARM_KEY_DOWN, NARM_KEY_ACTION_PRESS, 0, NARM_KEY_MOD_ALT);
    require(selectedIndex == selectedBefore, "System Alt chords must not move application selection");
    startNameEdit(1); text(editName, sizeof editName, "New"); editLen = 3;
    press(NARM_KEY_P, NARM_KEY_ACTION_PRESS, 'p');
    require(std::string(editName) == "Newp" && audioStopped, "Name entry must treat player shortcut letters as text");
    press(NARM_KEY_ESCAPE); require(mode == 0, "Escape must cancel name editing");
}
void fileContents() {
    setup();
    std::string contents;
    for (int i = 0; i < 300; ++i) contents += static_cast<char>('A' + i % 26);
    mock::addText("/document.txt", contents);
    select("document.txt"); openSelected(); serviceFileViewLoad();
    require(mode == 1 && previewLen == 128 && std::memcmp(viewBuf, contents.data(), 128) == 0,
            "File inspector must load actual file bytes");
    clearHits(); hitDown = 1; applyFileViewInput(); serviceFileViewLoad();
    require(viewOffset == 128 && std::memcmp(viewBuf, contents.data() + 128, 128) == 0,
            "File inspector paging must advance through actual file bytes");
    clearHits(); hitBack = 1; applyFileViewInput();
    require(mode == 0 && std::string(cwd) == "/", "Returning from inspector must preserve the directory");
    select("document.txt"); startRenameEdit();
    text(editName, sizeof editName, "renamed.txt"); editLen = 11; finishNameEdit();
    for (int i = 0; i < 128 && renameBusy; ++i) { inputNow = mock::now += 4; serviceFileRenameCopy(); }
    auto *renamed = mock::node("/renamed.txt", 1);
    require(!renameBusy && !mock::node("/document.txt", 1) && renamed &&
            std::string(renamed->bytes.begin(), renamed->bytes.end()) == contents,
            "File rename must preserve all content before removing the source");
}
// Compare the framebuffer produced by the real incremental renderer with a
// complete render of exactly the same application state. Every pixel counts:
// neither status, borders, footer nor loading indicators are masked out.
// Retain the incremental framebuffer afterwards so an expected-frame repaint
// cannot hide stale pixels from later transitions in the sequence.
void compareCleanFrame(const std::string &label) {
    const auto incremental = mock::pixels;
    dirty = 1; quickMoveDirty = nameEditQuickDirty = 0; render();
    int differences = 0, minX = 640, minY = 480, maxX = -1, maxY = -1;
    for (int y = 0; y < 480; ++y) for (int x = 0; x < 640; ++x) {
        if (incremental[y * 640 + x] == mock::pixels[y * 640 + x]) continue;
        ++differences; minX = std::min(minX, x); minY = std::min(minY, y);
        maxX = std::max(maxX, x); maxY = std::max(maxY, y);
    }
    ++checks; ++frameComparisons;
    if (differences) {
        std::string failure = label + ": " + std::to_string(differences) +
            " stale/different pixels at [" + std::to_string(minX) + "," +
            std::to_string(minY) + "]..[" + std::to_string(maxX) + "," +
            std::to_string(maxY) + "]";
        frameFailures.push_back(failure);
        if (!frameDirectory.empty()) {
            std::filesystem::create_directories(frameDirectory);
            const std::string name = "cleanup-" + std::to_string(frameComparisons);
            mock::bitmap(frameDirectory / (name + "-expected.bmp"));
            mock::pixels = incremental;
            mock::bitmap(frameDirectory / (name + "-actual.bmp"));
        }
    }
    mock::pixels = incremental;
}
void incrementalFrame(const std::string &label, bool mustStayPartial = false) {
    const int clearsBefore = mock::clears;
    render();
    if (mustStayPartial) {
        ++checks;
        if (mock::clears != clearsBefore)
            frameFailures.push_back(label + ": unnecessarily cleared the whole framebuffer");
    }
    compareCleanFrame(label);
}
void cleanBaseline() {
    dirty = 1; quickMoveDirty = nameEditQuickDirty = 0; render();
}
void press(uint keyId, uint character = 0) {
    mock::keyEvents.push_back({keyId, NARM_KEY_ACTION_PRESS, 0, character});
    updateInput(); applyInput();
}
void cleanupRegression(const std::filesystem::path &directory) {
    frameDirectory = directory;
    frameFailures.clear();
    setup();
    mock::addFile("/00 A long audio filename wrapping onto rows.wav", mock::wav());
    mock::addDirectory("/01 D");
    mock::addFile("/02 application.narm", mock::program());
    mock::addText("/03 a.txt", "Example text");
    mock::addText("/04 image.bmp", "BM");
    select("00 A long audio filename wrapping onto rows.wav"); cleanBaseline();
    for (int i = 1; i < 5; ++i) {
        press(NARM_KEY_DOWN);
        incrementalFrame("selection " + std::to_string(i) + " changes type/name/details", true);
    }
    for (int i = 3; i >= 0; --i) {
        press(NARM_KEY_UP);
        incrementalFrame("selection " + std::to_string(i) + " restores previous row", true);
    }
    deleteSelected(); incrementalFrame("delete confirmation appears");
    press(NARM_KEY_DOWN);
    require(!confirmDelete && statusCode == 0,
            "Moving selection must dismiss both delete confirmation and its prompt text");
    incrementalFrame("selection cancels delete confirmation including its top border", true);

    // Timeline updates and seeks must clear old digits, marker positions,
    // progress fill, icon glyphs and short/long state labels.
    select("00 A long audio filename wrapping onto rows.wav"); openSelected();
    mock::position = mock::rate * 119; mock::now += 1000; serviceAudio(); cleanBaseline();
    mock::position = mock::rate * 120; mock::now += 100; serviceAudio();
    incrementalFrame("audio timer changes 01:59 to 02:00", true);
    audioSeekTo(mock::rate * 5);
    incrementalFrame("audio seek backwards erases old progress and time", true);
    toggleAudioPause(); incrementalFrame("audio pause label and icon replace playing");
    toggleAudioPause(); incrementalFrame("audio resume label and icon replace paused");
    stopAudioPlayback(); incrementalFrame("audio stop resets time and progress");
    audioSeekTo(mock::rate * 179);
    incrementalFrame("stopped seek updates playhead only", true);
    toggleAudioPause(); incrementalFrame("stopped playback restarts at selected playhead");
    mock::position = mock::total; mock::flags = 0; mock::now += 1000; serviceAudio();
    incrementalFrame("finished audio replaces active labels and status");
    toggleAudioPause(); cleanBaseline();
    mock::position = mock::total; mock::flags = 0; mock::now += 1000; serviceAudio();
    press(NARM_KEY_DOWN);
    incrementalFrame("audio completion plus selection preserves pending status invalidation");
    press(NARM_KEY_UP); cleanBaseline();
    toggleAudioPause(); cleanBaseline();
    mock::position = mock::rate * 67; mock::now += 1000; serviceAudio();
    press(NARM_KEY_DOWN);
    incrementalFrame("audio progress and selection update together without a full clear", true);
    press(NARM_KEY_UP); cleanBaseline();
    mock::pixels.fill(6);
    mock::events.push_back(NARM_EVENT_FOCUS_GAINED); handleSystemEvents();
    mock::position = mock::total; mock::flags = 0; mock::now += 1000; serviceAudio();
    press(NARM_KEY_DOWN);
    incrementalFrame("focus, audio completion and selection retain the full repaint");
    mock::addFile("/short.wav", mock::wav()); select("short.wav"); openSelected();
    incrementalFrame("short track replaces long title without leftover letters");

    startNameEdit(1);
    text(editName, sizeof editName, "A very long file name to erase"); editLen = std::strlen(editName);
    cleanBaseline();
    for (int i = 0; i < 8; ++i) {
        press(NARM_KEY_BACKSPACE);
        incrementalFrame("name editor deletes character " + std::to_string(i), true);
    }
    press(NARM_KEY_A, 'a'); incrementalFrame("name editor inserts character after deletion", true);
    press(NARM_KEY_ESCAPE); incrementalFrame("cancel name editor restores browser");

    // The scheduler's shared VGA framebuffer may contain an unrelated app's
    // frame when focus returns. A focus-gain event must repaint everything.
    mock::focus = false; mock::events.push_back(NARM_EVENT_FOCUS_LOST); handleSystemEvents();
    for (std::size_t i = 0; i < mock::pixels.size(); ++i) mock::pixels[i] = (i / 13) & 15;
    mock::focus = true; mock::events.push_back(NARM_EVENT_FOCUS_GAINED); handleSystemEvents();
    incrementalFrame("focus gain replaces every pixel of another application's frame");
    press(NARM_KEY_UP); cleanBaseline();
    mock::pixels.fill(4);
    mock::events.push_back(NARM_EVENT_FOCUS_GAINED); handleSystemEvents();
    press(NARM_KEY_DOWN);
    incrementalFrame("focus gain plus immediate selection cannot downgrade a complete repaint");
    startNameEdit(1); text(editName, sizeof editName, "Draft"); editLen = 5; cleanBaseline();
    mock::pixels.fill(13);
    mock::events.push_back(NARM_EVENT_FOCUS_GAINED); handleSystemEvents();
    press(NARM_KEY_A, 'a');
    incrementalFrame("focus gain plus immediate name typing cannot downgrade a complete repaint");

    setup();
    for (int i = 0; i < 28; ++i)
        mock::addText("/entry-" + std::to_string(100 + i) + ".txt", "Test");
    startRefresh(); inputNow = mock::now += 4; serviceSd(); cleanBaseline();
    // Actual loop order: storage completes more rows after render; then the
    // next iteration receives a key before the pending full redraw is done.
    inputNow = mock::now += 4; serviceSd();
    press(NARM_KEY_DOWN);
    incrementalFrame("selection preserves pending partial-directory-scan invalidation");
    for (int i = 0; i < 64 && (cacheLoading || scanActive || selectedInfoDirty); ++i) {
        inputNow = mock::now += 4; serviceSd();
        if (dirty || audioPanelDirty)
            incrementalFrame("directory scan publishes rows, count and reading status " + std::to_string(i));
    }
    press(0x4e); // Normalized USB HID Page Down ID.
    incrementalFrame("page down replaces list, selection and scrollbar");
    for (int i = 0; i < 8 && cacheLoading; ++i) {
        inputNow = mock::now += 4; serviceSd();
        if (dirty) incrementalFrame("scrolled cache load replaces visible rows " + std::to_string(i));
    }
    if (!frameFailures.empty()) {
        std::string failures = "Incremental UI cleanup regressions:";
        for (const auto &failure : frameFailures) failures += "\n  " + failure;
        throw std::runtime_error(failures);
    }
}
void previews(const std::filesystem::path &directory) {
    std::filesystem::create_directories(directory);
    setup();
    mock::addDirectory("/Applications"); mock::addDirectory("/Documents"); mock::addDirectory("/Music");
    mock::addFile("/calc640.narm", mock::program());
    mock::addFile("/mmbasic.narm", mock::program());
    mock::addFile("/synthStudio.narm", mock::program());
    mock::addFile("/Midnight in the workshop.wav", mock::wav());
    mock::addText("/README.txt", "Welcome to your RP2350 computer.\nChoose a program and press Enter to open it.\nAlt+F2 switches applications.\nMusic can continue while you browse.\n");
    select("Midnight in the workshop.wav"); openSelected();
    mock::position = 48000 * 90; mock::now += 1000; serviceAudio();
    dirty = 1; quickMoveDirty = 0; render();
    require(SCREEN_W == 640 && SCREEN_H == 480 && mock::presents > 0, "Application must draw the 640x480 framebuffer");
    require(mock::pixels[407 * 640 + 100] == 11 && mock::pixels[407 * 640 + 450] == 14,
            "Three-minute audio at 90 seconds must draw a half-filled progress bar without 32-bit overflow");
    mock::bitmap(directory / "browser-playing.bmp");
    select("README.txt"); openSelected(); serviceFileViewLoad(); dirty = 1; render();
    mock::bitmap(directory / "viewer.bmp");
    mode = 0; startNameEdit(2); text(editName, sizeof editName, "New recordings"); editLen = 14;
    dirty = 1; render(); mock::bitmap(directory / "name-edit.bmp");
    mode = 0; statusCode = 1; text(cwd, sizeof cwd, "/Documents"); selectedIndex = scrollIndex = 0; scan(); dirty = 1; render();
    mock::bitmap(directory / "empty-folder.bmp");
}
}

#ifndef FILEMGR_HOST_NO_MAIN
int main(int argc, char **argv) {
    try {
        test::launches(); test::audio(); test::focusAndFiles(); test::input(); test::fileContents();
        test::cleanupRegression(argc > 1 ? argv[1] : "previews");
        test::previews(argc > 1 ? argv[1] : "previews");
        std::cout << "PASS: " << test::checks << " FILEMGR assertions, including " << test::frameComparisons
                  << " complete framebuffer cleanup comparisons; 4 real UI previews rendered.\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << "FAIL after " << test::checks << " assertions: " << error.what() << '\n';
        return 1;
    }
}

#endif
