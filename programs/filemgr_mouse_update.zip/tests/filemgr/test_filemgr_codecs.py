"""Reference tests for real FILEMGR PNG/JPEG decoders.

Requires Pillow and libjpeg's cjpeg/djpeg tools for test fixtures/reference RGB.
Production FILEMGR does not depend on those tools. The host driver includes
actual Tiny-C decoder code; optional native tests execute the compiled Thumb.
"""
import argparse,shutil,tempfile
from pathlib import Path
import struct,zlib,subprocess,json
from PIL import Image
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'codec-test-artifacts'
DRIVER=ROOT/'filemgr_codec_host_tests.exe'
PALETTE=[255,0,2,16,224,128,97,236,252,28,9,159,7,227,73,146]
def expand(p):return ((p>>5)*255//7,((p>>2)&7)*255//7,(p&3)*85)
PALRGB=[expand(p) for p in PALETTE]
LUT=[min(range(16),key=lambda i:sum((a-b)**2 for a,b in zip(expand(c),PALRGB[i]))) for c in range(256)]
def quant(r,g,b):return LUT[((r>>5)<<5)|((g>>5)<<2)|(b>>6)]
def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
def paeth(a,b,c):
 p=a+b-c;dist=[abs(p-a),abs(p-b),abs(p-c)];return (a,b,c)[dist.index(min(dist))]
def make_png(w,h,depth,kind,interlace,method='dynamic',transparency=True):
 channels={0:1,2:3,3:1,4:2,6:4}[kind];maximum=(1<<depth)-1
 entries=min(256,1<<depth) if kind==3 else 0
 palette=[((i*73)%256,(i*29)%256,(i*113)%256) for i in range(entries)]
 alpha=[(i*37)%256 for i in range(entries)]
 values=[];expected=[]
 for y in range(h):
  row=[]
  for x in range(w):
   r=(x*29+y*7)%256;g=(x*13+y*31)%256;b=(x*17+y*11)%256;a=(x*41+y*19)%256
   if depth==16:r,g,b,a=[(v*257+(x+y)*7)&65535 for v in (r,g,b,a)]
   if kind in (0,3):samples=[(x*3+y*5)%(maximum+1)]
   elif kind==2:samples=[r,g,b]
   elif kind==4:samples=[r,a]
   else:samples=[r,g,b,a]
   row.append(samples)
   if kind==3:
    rr,gg,bb=palette[samples[0]];aa=alpha[samples[0]] if transparency else 255
   else:
    rr=samples[0];gg=samples[1] if kind in (2,6) else rr;bb=samples[2] if kind in (2,6) else rr
    aa=samples[-1] if kind in (4,6) else maximum
    if transparency and kind==0 and samples[0]==0:aa=0
    if transparency and kind==2 and samples[:3]==[0,0,0]:aa=0
    if depth==16:rr,gg,bb,aa=[v>>8 for v in (rr,gg,bb,aa)]
    elif depth<8:rr=gg=bb=rr*255//maximum;aa=255 if aa else 0
   rr,gg,bb=[(v*aa+255*(255-aa)+127)//255 for v in (rr,gg,bb)]
   expected.append(quant(rr,gg,bb))
  values.append(row)
 passes=[(0,0,1,1)] if not interlace else [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
 raw=bytearray();bpp=max(1,(channels*depth+7)//8)
 for sx,sy,dx,dy in passes:
  if sx>=w or sy>=h:continue
  prev=None
  for row_no,y in enumerate(range(sy,h,dy)):
   samples=[s for x in range(sx,w,dx) for s in values[y][x]]
   if depth==16:line=bytearray(b''.join(struct.pack('>H',s) for s in samples))
   elif depth==8:line=bytearray(samples)
   else:
    line=bytearray((len(samples)*depth+7)//8)
    for i,s in enumerate(samples):line[i*depth//8]|=s<<(8-depth-(i*depth)%8)
   if prev is None:prev=bytearray(len(line))
   filt=row_no%5;raw.append(filt)
   for i,v in enumerate(line):
    left=line[i-bpp] if i>=bpp else 0;up=prev[i];ul=prev[i-bpp] if i>=bpp else 0
    predictor=(0,left,up,(left+up)//2,paeth(left,up,ul))[filt]
    raw.append((v-predictor)&255)
   prev=line
 if method=='stored':compressor=zlib.compressobj(0)
 elif method=='fixed':compressor=zlib.compressobj(6,zlib.DEFLATED,15,8,zlib.Z_FIXED)
 else:compressor=zlib.compressobj(6)
 compressed=compressor.compress(raw)+compressor.flush()
 data=bytearray(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,depth,kind,0,0,int(interlace))))
 if kind==3:data+=chunk(b'PLTE',bytes(v for p in palette for v in p))
 if transparency and kind==3:data+=chunk(b'tRNS',bytes(alpha))
 elif transparency and kind==0:data+=chunk(b'tRNS',b'\0\0')
 elif transparency and kind==2:data+=chunk(b'tRNS',b'\0'*6)
 sizes=[1,2,7,4096];i=0;pos=0
 while pos<len(compressed):
  part=compressed[pos:pos+sizes[i%4]];pos+=len(part);i+=1;data+=chunk(b'IDAT',part)
 data+=chunk(b'IEND',b'')
 return bytes(data),expected

def run_png():
 results=[]
 for kind,depths in ((0,(1,2,4,8,16)),(2,(8,16)),(3,(1,2,4,8)),(4,(8,16)),(6,(8,16))):
  for depth in depths:
   for interlace in (False,True):
    for method in ('stored','fixed','dynamic'):
     name=f'png_{kind}_{depth}_{int(interlace)}_{method}'
     data,expected=make_png(17,13,depth,kind,interlace,method)
     source=OUT/(name+'.png');source.write_bytes(data)
     cache=OUT/(name+'.cache')
     p=subprocess.run([str(DRIVER),str(source),str(cache)],capture_output=True,text=True)
     if p.returncode:raise AssertionError(name+': '+p.stdout+p.stderr)
     payload=cache.read_bytes();actual=[((payload[512+y*9+x//2]>>(4 if x%2==0 else 0))&15) for y in range(13) for x in range(17)]
     if actual!=expected:
      bad=[(i,a,b) for i,(a,b) in enumerate(zip(actual,expected)) if a!=b];raise AssertionError((name,bad[:10]))
     results.append(name)
 for w,h,kind in ((257,129,2),(640,480,6)):
  name=f'png_large_{w}_{h}';data,expected=make_png(w,h,8,kind,True,'dynamic')
  source=OUT/(name+'.png');source.write_bytes(data);cache=OUT/(name+'.cache')
  p=subprocess.run([str(DRIVER),str(source),str(cache)],capture_output=True,text=True)
  if p.returncode:raise AssertionError(name+': '+p.stdout+p.stderr)
  payload=cache.read_bytes();stride=(w+1)//2
  actual=[((payload[512+y*stride+x//2]>>(4 if x%2==0 else 0))&15) for y in range(h) for x in range(w)]
  assert actual==expected,name
  print(p.stdout.strip());results.append(name)
 print(f'PASS: {len(results)} PNG fixtures, all color types/depths, Adam7, all filters, stored/fixed/dynamic DEFLATE, split IDAT, alpha/tRNS and window wrap')
 (OUT/'png_results.json').write_text(json.dumps(results,indent=2))
def check(path, reference=None):
 cache=path.with_suffix('.cache');rgb=path.with_suffix('.rgb')
 p=subprocess.run([str(DRIVER),str(path),str(cache),str(rgb)],capture_output=True,text=True)
 if p.returncode:raise AssertionError(path.name+': '+p.stdout+p.stderr)
 if reference is None:
  ppm=path.with_suffix('.ppm')
  decoded=subprocess.run([str(DCT),'-dct','float','-nosmooth','-pnm','-outfile',str(ppm),str(path)],capture_output=True)
  reference=Image.open(ppm).convert('RGB') if decoded.returncode==0 else Image.open(path).convert('RGB')
 expected=reference.tobytes();actual=rgb.read_bytes()
 errors=[abs(a-b) for a,b in zip(actual,expected)]
 maximum=max(errors);mean=sum(errors)/len(errors)
 if maximum>3 or mean>0.6:
  i=errors.index(maximum);raise AssertionError((path.name,'RGB error',maximum,mean,'at byte',i,'actual',actual[i:i+12],'expected',expected[i:i+12]))
 w,h=reference.size;payload=cache.read_bytes();stride=(w+1)//2
 for y in range(h):
  for x in range(w):
   i=(y*w+x)*3;target=quant(*actual[i:i+3]);packed=payload[512+y*stride+x//2];value=(packed>>(4 if x%2==0 else 0))&15
   assert value==target,(path.name,'packed pixel',x,y)
 return {'name':path.name,'max_rgb_error':maximum,'mean_rgb_error':mean,'log':p.stdout.strip()}

def run_jpeg():
 results=[]
 for w,h in ((17,13),(64,35),(160,120)):
  for mode in ('RGB','L','CMYK'):
   image=Image.new('RGB',(w,h));image.putdata([((x*29+y*7)%256,(x*13+y*31)%256,(x*17+y*11)%256) for y in range(h) for x in range(w)])
   image=image.convert(mode)
   for quality in (25,75,95):
    for sub in ((0,1,2) if mode=='RGB' else (0,)):
     for progressive in (False,True):
      name=f'jpg_{w}_{h}_{mode}_{quality}_{sub}_{int(progressive)}'
      path=OUT/(name+'.jpeg');image.save(path,'JPEG',quality=quality,subsampling=sub,progressive=progressive)
      results.append(check(path))
 image=Image.new('RGB',(65,39));image.putdata([((x*17)%256,(y*29)%256,((x+y)*11)%256) for y in range(39) for x in range(65)])
 ppm=OUT/'jpeg_encoder_input.ppm';image.save(ppm)
 scan=OUT/'sequential.scans';scan.write_text('0; 1; 2;\n')
 options=[('restart',['-restart','1B']),('progressive_restart',['-progressive','-restart','1B']),('sequential_multiscan',['-scans',str(scan)]),('rgb',['-rgb']),('quant16',['-quality','1']),('sample411',['-sample','4x1,1x1,1x1']),('sample440',['-sample','1x2,1x1,1x1']),('sample410',['-sample','4x2,1x1,1x1']),('sample311',['-sample','3x1,1x1,1x1']),('gray_sample4',['-grayscale','-sample','4x4'])]
 for name,opts in options:
  path=OUT/('jpg_'+name+'.jpeg')
  p=subprocess.run([str(CJPEG),*opts,'-outfile',str(path),str(ppm)],capture_output=True)
  assert p.returncode==0,p.stderr
  results.append(check(path))
 base=(OUT/'jpg_restart.jpeg').read_bytes();path=OUT/'jpg_large_app1.jpeg';path.write_bytes(base[:2]+b'\xff\xe1'+(60002).to_bytes(2,'big')+b'X'*60000+base[2:]);results.append(check(path))
 ycck=OUT/'jpg_progressive_ycck.jpeg';ycck.write_bytes((ROOT/'fixtures/progressive_ycck.jpeg').read_bytes());results.append(check(ycck))
 print(f'PASS: {len(results)} JPEG fixtures, baseline/progressive, 4:4:4/4:2:2/4:2:0, grayscale/CMYK, restarts, multi-scan, RGB, 16-bit quantization and large metadata')
 print('Maximum RGB error vs reference:',max(r['max_rgb_error'] for r in results),'mean:',max(r['mean_rgb_error'] for r in results))
 (OUT/'jpeg_results.json').write_text(json.dumps(results,indent=2))


def replace_png_chunk(data,kind,mutate):
    output=bytearray(data[:8]);pos=8;done=False
    while pos<len(data):
        size=struct.unpack_from('>I',data,pos)[0];tag=data[pos+4:pos+8];body=data[pos+8:pos+8+size]
        if tag==kind and not done:body=mutate(body);done=True
        output+=chunk(tag,body);pos+=12+size
    assert done
    return bytes(output)

def negative_cases():
    source,expected=make_png(17,13,8,6,True)
    cases=[('png_truncated',source[:-3]),('png_crc',source[:29]+bytes([source[29]^1])+source[30:])]
    cases.append(('png_interlace',replace_png_chunk(source,b'IHDR',lambda body:body[:-1]+b'\2')))
    cases.append(('png_unknown_critical',source[:33]+chunk(b'BORK',b'')+source[33:]))
    cases.append(('png_row_limit',make_png(4097,1,8,6,False)[0]))
    # Change Adler-32 while preserving every PNG chunk CRC.
    chunks=[];pos=8;compressed=bytearray()
    while pos<len(source):
        size=struct.unpack_from('>I',source,pos)[0];tag=source[pos+4:pos+8];body=source[pos+8:pos+8+size]
        if tag==b'IDAT':compressed+=body
        else:chunks.append((tag,body))
        pos+=size+12
    compressed[-1]^=1
    damaged=b'\x89PNG\r\n\x1a\n'+b''.join(chunk(tag,body) for tag,body in chunks if tag!=b'IEND')+chunk(b'IDAT',compressed)+chunk(b'IEND',b'')
    cases.append(('png_adler',damaged))
    original=(OUT/'jpg_restart.jpeg').read_bytes()
    cases.append(('jpeg_truncated',original[:-2]))
    sof=next(i for i in range(len(original)-1) if original[i:i+2] in (b'\xff\xc0',b'\xff\xc1'))
    changed=bytearray(original);changed[sof+1]=0xc9;cases.append(('jpeg_arithmetic',bytes(changed)))
    changed=bytearray(original);changed[sof+4]=12;cases.append(('jpeg_precision12',bytes(changed)))
    dqt=original.index(b'\xff\xdb');changed=bytearray(original);changed[dqt+5]=0;cases.append(('jpeg_zero_quantizer',bytes(changed)))
    restart=next(i for i in range(len(original)-1) if original[i]==255 and 0xd0<=original[i+1]<=0xd7)
    changed=bytearray(original);changed[restart+1]=0xd7;cases.append(('jpeg_restart_sequence',bytes(changed)))
    progressive=(OUT/'jpg_progressive_restart.jpeg').read_bytes();sos=progressive.index(b'\xff\xda');length=int.from_bytes(progressive[sos+2:sos+4],'big')
    changed=bytearray(progressive);changed[sos+length+1]=0xff;cases.append(('jpeg_bad_approximation',bytes(changed)))
    for name,data in cases:
        path=OUT/(name+('.png' if name.startswith('png') else '.jpeg'));path.write_bytes(data)
        result=subprocess.run([str(DRIVER),str(path),str(path.with_suffix('.cache'))],capture_output=True,text=True,timeout=20)
        assert result.returncode!=0,(name,'unexpected success')
    print(f'PASS: {len(cases)} malformed/unsupported inputs rejected (CRC/Adler, truncation, variants, tables and restarts)')

def main():
    global OUT,DRIVER,DCT,CJPEG
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--driver',type=Path,default=DRIVER)
    parser.add_argument('--runtime-driver',type=Path)
    parser.add_argument('--workdir',type=Path)
    parser.add_argument('--djpeg',type=Path,default=shutil.which('djpeg'))
    parser.add_argument('--cjpeg',type=Path,default=shutil.which('cjpeg'))
    args=parser.parse_args();DRIVER=args.driver.resolve()
    if not args.djpeg or not args.cjpeg:parser.error('libjpeg cjpeg and djpeg are required; pass --cjpeg/--djpeg or add them to PATH')
    DCT=args.djpeg.resolve();CJPEG=args.cjpeg.resolve()
    def run():
        OUT.mkdir(parents=True,exist_ok=True)
        run_png();run_jpeg();negative_cases()
        if args.runtime_driver:
            subprocess.run([str(args.runtime_driver.resolve()),str(OUT/'png_6_8_1_dynamic.png'),str(OUT/'jpg_64_35_RGB_95_2_1.jpeg')],check=True)
    if args.workdir:OUT=args.workdir.resolve();run()
    else:
        with tempfile.TemporaryDirectory(prefix='filemgr_codecs_') as directory:OUT=Path(directory);run()

if __name__=='__main__':main()
