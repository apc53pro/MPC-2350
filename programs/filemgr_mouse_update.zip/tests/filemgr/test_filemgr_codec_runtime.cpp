#define FILEMGR_HOST_NO_MAIN
#include "filemgr_host_tests.cpp"

void openCodecFixture(const char* filename) {
 test::setup();std::ifstream input(filename,std::ios::binary);std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(input)),{});
 test::require(!bytes.empty(),"Codec fixture exists");mock::addFile("/IMAGE.JPEG",bytes);test::select("IMAGE.JPEG");openSelected();
 test::require(mode==4 && imageCacheActive,"Recognized compressed image enters incremental decoder");
}
void cancelCodec() {
 hitBack=1;applyImageViewInput();hitBack=0;
 test::require(mode==0 && !codecMode && !imageCacheActive,"Cancel stops decoder");
 test::require(!mock::node(imageCachePath,1) && !mock::node(codecScratchPath,1),"Cancel removes both temporary files");
}
int main(int argc,char**argv) {
 try {
  test::require(argc==3,"Pass PNG and progressive JPEG fixtures");
  char jpegName[]="Example.JpEg";char jpgName[]="image.JPG";char pngName[]="image.PNG";
  test::require(fmNameImage(jpegName,12) && fmNameImage(jpgName,9) && fmNameImage(pngName,9),"Image extensions are case-insensitive, including .jpeg");
  openCodecFixture(argv[1]);serviceImageCacheBuild();cancelCodec();
  openCodecFixture(argv[1]);for(int i=0;i<20 && codecStage<2;++i)serviceImageCacheBuild();serviceImageCacheBuild();cancelCodec();
  openCodecFixture(argv[2]);for(int i=0;i<10000 && !codecScratchExists;++i)serviceImageCacheBuild();
  test::require(codecScratchExists,"JPEG creates bounded coefficient backing store");cancelCodec();
  openCodecFixture(argv[2]);for(int i=0;i<10000 && (codecStage<2 || jpegStage!=1);++i)serviceImageCacheBuild();
  test::require(jpegStage==1,"JPEG coefficient decode begins");serviceImageCacheBuild();cancelCodec();
  openCodecFixture(argv[2]);for(int i=0;i<100000 && (codecStage<2 || jpegStage!=3);++i)serviceImageCacheBuild();
  test::require(jpegStage==3 && imageReadingSource==2,"JPEG reaches coefficient-to-pixel conversion");
  mock::readLimit=1;mock::limitedReadPath=mock::normalized(codecScratchPath);serviceImageCacheBuild();
  test::require(imageCacheError && imageCodecError==3 && !imageCacheReady && !codecScratchExists,"Coefficient read failure cannot publish a successful image");
  openCodecFixture(argv[1]);for(int i=0;i<20 && codecStage<2;++i)serviceImageCacheBuild();
  mock::writeLimit=1;for(int i=0;i<10000 && imageCacheActive;++i)serviceImageCacheBuild();
  test::require(imageCacheError && imageCodecError==3 && !imageCacheReady,"Short packed-cache write rejects compressed image");
  openCodecFixture(argv[2]);for(int i=0;i<10000 && (codecStage<2 || jpegStage!=1);++i)serviceImageCacheBuild();
  mock::writeLimit=1;for(int i=0;i<10000 && imageCacheActive;++i)serviceImageCacheBuild();
  test::require(imageCacheError && imageCodecError==3 && !codecScratchExists,"Coefficient write error is reported and cleaned up");
  openCodecFixture(argv[1]);mock::readLimit=1;mock::limitedReadPath="/IMAGE.JPEG";
  for(int i=0;i<10000 && imageCacheActive;++i)serviceImageCacheBuild();
  test::require(imageCacheError && imageCodecError==3,"Source read error stops compressed decoding");
  std::cout<<"PASS: "<<test::checks<<" codec runtime assertions; extension handling, cancellation and source/cache/coefficient I/O failures.\n";
 }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}
