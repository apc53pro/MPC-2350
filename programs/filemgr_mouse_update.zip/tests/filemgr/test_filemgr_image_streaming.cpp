// Real FILEMGR source, deterministic storage, independent pixel/cache reference.
#define FILEMGR_HOST_NO_MAIN
#include "filemgr_host_tests.cpp"

namespace image_test {
int cases = 0;
unsigned scene(int x, int y, int seed, bool gray = false) {
    if (gray) return ((x / 7 + y / 5 + seed) & 1) ? 0u : 1u;
    return unsigned(x / 7 + (y / 5) * 3 + seed) & 15u;
}
std::array<unsigned char, 3> rgb(unsigned index) {
    static const unsigned palette[] = {255,0,2,16,224,128,97,236,252,28,9,159,7,227,73,146};
    unsigned p = palette[index], r = p >> 5, g = (p >> 2) & 7, b = p & 3;
    return {static_cast<unsigned char>(r * 255 / 7), static_cast<unsigned char>(g * 255 / 7), static_cast<unsigned char>(b * 85)};
}
void put16(std::vector<unsigned char>& bytes, int pos, unsigned value) {
    bytes[pos] = value; bytes[pos + 1] = value >> 8;
}
void put32(std::vector<unsigned char>& bytes, int pos, unsigned value) {
    put16(bytes, pos, value); put16(bytes, pos + 2, value >> 16);
}
std::vector<unsigned char> bmp(int width, int height, int bits, bool topDown, int seed) {
    int stride = ((width * bits + 31) / 32) * 4;
    std::vector<unsigned char> bytes(54 + stride * height);
    bytes[0] = 'B'; bytes[1] = 'M'; put32(bytes, 2, bytes.size()); put32(bytes, 10, 54);
    put32(bytes, 14, 40); put32(bytes, 18, width); put32(bytes, 22, topDown ? -height : height);
    put16(bytes, 26, 1); put16(bytes, 28, bits); put32(bytes, 34, stride * height);
    for (int y = 0; y < height; ++y) for (int x = 0; x < width; ++x) {
        auto color = rgb(scene(x, y, seed));
        int offset = 54 + (topDown ? y : height - y - 1) * stride + x * (bits / 8);
        bytes[offset] = color[2]; bytes[offset + 1] = color[1]; bytes[offset + 2] = color[0];
        if (bits == 32) bytes[offset + 3] = static_cast<unsigned char>(x ^ y); // alpha ignored
    }
    return bytes;
}
std::vector<unsigned char> pnm(int width, int height, int seed, bool gray) {
    std::string header = std::string(gray ? "P5\n" : "P6\n") + "# streaming fixture\n" + std::to_string(width) + " " + std::to_string(height) + "\n255\n";
    std::vector<unsigned char> bytes(header.begin(), header.end());
    for (int y = 0; y < height; ++y) for (int x = 0; x < width; ++x) {
        auto color = rgb(scene(x, y, seed, gray));
        bytes.push_back(color[0]);
        if (!gray) { bytes.push_back(color[1]); bytes.push_back(color[2]); }
    }
    return bytes;
}
void load(const std::vector<unsigned char>& bytes, const std::string& name, unsigned storage = 1) {
    test::setup(); activeStorage = storage;
    mock::addFile("/" + name, bytes, storage); test::select(name); openSelected();
    test::require(mode == 4, "Supported image must enter viewer");
    for (int i = 0; i < 10000 && imageCacheActive; ++i) serviceImageCacheBuild();
    test::require(imageCacheReady && !imageCacheError, "Packed cache must finish");
}
void packed(int width, int height, int seed, bool gray) {
    auto* cache = mock::node(imageCachePath, activeStorage);
    test::require(cache && cache->bytes.size() == 512u + ((width + 1) / 2) * height, "Sector-aligned packed cache length");
    test::require(cache->bytes[12] == 2, "Packed cache format version");
    for (int y = 0; y < height; ++y) for (int x = 0; x < width; ++x) {
        auto value = cache->bytes[512 + y * ((width + 1) / 2) + x / 2];
        unsigned index = (x & 1) ? value & 15 : value >> 4;
        if (index != scene(x, y, seed, gray)) throw std::runtime_error("Packed pixel mismatch at " + std::to_string(x) + "," + std::to_string(y));
    }
    ++test::checks;
}
void frame(int width, int height, int seed, bool gray = false) {
    dirty = 1; render();
    test::require(!imageDrawError, "Image must render without read error");
    for (int y = 70; y < 368; ++y) for (int x = 0; x < 640; ++x) {
        auto sx = imageCenterX + ((int64_t(x) - 320) * 256) / imageScale;
        auto sy = imageCenterY + ((int64_t(y) - 219) * 256) / imageScale;
        unsigned expected = (sx < 0 || sx >= width || sy < 0 || sy >= height) ? 1 : scene(int(sx), int(sy), seed, gray);
        unsigned actual = mock::pixels[y * 640 + x];
        if (actual != expected) throw std::runtime_error("Viewport mismatch at " + std::to_string(x) + "," + std::to_string(y) + " actual=" + std::to_string(actual) + " expected=" + std::to_string(expected));
    }
    ++test::checks;
}
std::pair<unsigned, unsigned> reads() {
    unsigned count = 0, bytes = 0;
    for (const auto& call : mock::ioReads) if (call.path == mock::normalized(imageCachePath)) {
        ++count; bytes += call.returned;
        test::require(call.offset >= 512 && (call.offset - 512) % 4096 == 0 && call.requested <= 4096, "Reads must use aligned, non-overlapping blocks");
    }
    return {count, bytes};
}
void movement(int key) {
    hitRight = key == 0; hitDown = key == 1; hitZoomIn = key == 2; hitZoomOut = key == 3;
    applyImageViewInput();
    hitRight = hitDown = hitZoomIn = hitZoomOut = 0;
}
void one(const std::vector<unsigned char>& bytes, const std::string& name, int w, int h, int seed, bool gray = false, unsigned storage = 1) {
    load(bytes, name, storage); packed(w, h, seed, gray);
    mock::ioReads.clear(); frame(w, h, seed, gray);
    auto cold = reads(); auto payload = ((w + 1) / 2) * h;
    test::require(cold.first <= unsigned((payload + 4095) / 4096 + 1), "One viewport reads each required source block once");
    test::require(cold.second <= unsigned(payload + 4096), "Viewport must not repeatedly over-read rows");
    unsigned warmedBlocks = cold.first;
    for (int i = 0; i < 8; ++i) {
        mock::ioReads.clear(); movement(i % 4); frame(w, h, seed, gray);
        auto warm = reads();
        warmedBlocks += warm.first;
        if (payload <= 16384) test::require(warmedBlocks <= unsigned((payload + 4095) / 4096), "Small images retain every visited block across transforms");
        if (w == 160 && h == 120) test::require(warm.first == 0, "Test image must navigate without filesystem reads after first display");
        if (payload > 16384) test::require(warm.first <= unsigned((payload + 4095) / 4096 + 1), "Large-image navigation remains bounded by sequential block count");
        auto presents = mock::presents; inputNow += 200; render();
        test::require(mock::presents == presents, "Input must not schedule a duplicate delayed frame");
    }
    hitOpen = 1; applyImageViewInput(); hitOpen = 0; frame(w, h, seed, gray);
    hitBack = 1; applyImageViewInput(); hitBack = 0;
    test::require(mode == 0 && !mock::node(imageCachePath, activeStorage), "Closing viewer removes temporary cache");
    for (int i = 0; i < 4; ++i) test::require(imageBlockBase[i] == -1, "Closing viewer invalidates source blocks");
    ++cases;
}
void errors() {
    auto bytes = bmp(160, 120, 24, false, 3);
    test::setup(); mock::addFile("/broken.bmp", bytes); test::select("broken.bmp"); openSelected();
    mock::readLimit = 100; mock::limitedReadPath = "/broken.bmp";
    serviceImageCacheBuild(); test::require(imageCacheError && !imageCacheReady && !imageCacheActive, "Short source read stops cache build");
    test::setup(); mock::writeLimit = 100; mock::addFile("/header.bmp", bytes); test::select("header.bmp"); openSelected();
    test::require(imageCacheError && !imageCacheActive, "Short cache header must fail before decoding");
    test::setup(); mock::addFile("/write.bmp", bytes); test::select("write.bmp"); openSelected(); mock::writeLimit = 100;
    for (int i = 0; i < 100 && imageCacheActive; ++i) serviceImageCacheBuild();
    test::require(imageCacheError && !imageCacheReady, "Short cache write must not publish a ready image");
    load(bytes, "read.bmp"); mock::limitedReadPath = mock::normalized(imageCachePath); mock::readLimit = 100;
    mock::ioReads.clear(); dirty = 1; render();
    test::require(imageDrawError && mock::ioReads.size() == 1, "Read failure must latch instead of retrying once per pixel");
    dirty = 1; render(); test::require(mock::ioReads.size() == 1, "Error screen must not retry failed storage reads");
    // Back during preparation cancels both disk-cache and source-buffer state.
    test::setup(); mock::addFile("/cancel.bmp", bytes); test::select("cancel.bmp"); openSelected(); serviceImageCacheBuild();
    hitBack = 1; applyImageViewInput(); hitBack = 0;
    test::require(!imageCacheActive && !imageReadingSource && !mock::node(imageCachePath, 1), "Cancel preparation cleans up cache");
}
}
int main() {
    try {
        image_test::one(image_test::bmp(160,120,24,false,3),"test.BMP",160,120,3);
        image_test::one(image_test::bmp(641,481,24,false,5),"large.bmp",641,481,5);
        image_test::one(image_test::bmp(4097,7,24,false,11),"wide.bmp",4097,7,11);
        image_test::one(image_test::bmp(17,9,32,true,7),"top.bmp",17,9,7,false,0);
        image_test::one(image_test::pnm(129,259,9,false),"odd.ppm",129,259,9);
        image_test::one(image_test::pnm(131,35,1,true),"gray.pgm",131,35,1,true);
        image_test::errors();
        std::cout << "PASS: " << image_test::cases << " image formats/layouts, " << test::checks << " assertions; packed pixels, complete viewports, bounded block I/O, warm movement, cleanup and storage failures.\n";
    } catch (const std::exception& error) { std::cerr << "FAIL: " << error.what() << '\n'; return 1; }
}


