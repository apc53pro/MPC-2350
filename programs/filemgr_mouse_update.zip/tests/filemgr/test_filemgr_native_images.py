"""Execute FILEMGR image streaming, transforms and packed-cache writes as real Thumb code.

Firmware storage/video are deterministic mocks; this verifies generated code and
I/O counts, not RP2350 wall-clock timing. Uses test_filemgr_native_graphics' loader.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import struct
import tempfile
from test_filemgr_native_graphics import NativeVideo, compile_source, signed, arm, CONTEXT, STUB

ROOT = Path(__file__).resolve().parent
PALETTE = [255,0,2,16,224,128,97,236,252,28,9,159,7,227,73,146]

def scene(x, y, seed):
    return (x // 7 + (y // 5) * 3 + seed) & 15

def fixture_pixels(width, height, seed):
    return [[scene(x, y, seed) for x in range(width)] for y in range(height)]

def sample(width, height, seed, bits, top_down):
    stride = ((width * bits + 31) // 32) * 4
    body = bytearray(stride * height)
    for y in range(height):
        for x in range(width):
            p = PALETTE[scene(x, y, seed)]
            r,g,b = (p >> 5) * 255 // 7, ((p >> 2) & 7) * 255 // 7, (p & 3) * 85
            offset = (y if top_down else height - 1 - y) * stride + x * (bits // 8)
            body[offset:offset+3] = bytes((b,g,r))
            if bits == 32: body[offset+3] = (x ^ y) & 255
    header = b'BM' + struct.pack('<IHHI', 54+len(body),0,0,54)
    header += struct.pack('<IiiHHIIiiII',40,width,-height if top_down else height,1,bits,0,len(body),0,0,0,0)
    return header + body

class ImageMachine(NativeVideo):
    def __init__(self, image, sample):
        super().__init__(image)
        self.files = {'/head.bmp': bytearray(sample)}
        self.reads = []
        self.write32(CONTEXT + 64, CONTEXT + 0x300)
        self.write32(CONTEXT + 0x300, 12)
        self.write32(CONTEXT + 0x308, STUB + 0x71)

    def run(self):
        from test_filemgr_native_graphics import STOP
        self.uc.emu_start(self.entry | 1, STOP + 2, count=800_000_000)
        assert self.finished, f"native image fixture exceeded instruction budget: {len(self.snapshots)} frames, {len(self.reads)} reads"
        assert self.uc.reg_read(arm.UC_ARM_REG_R0) == 0, f"native fixture error {self.uc.reg_read(arm.UC_ARM_REG_R0)}"

    def callback(self, uc, address, size, user):
        if address != STUB + 0x70:
            return super().callback(uc, address, size, user)
        command = uc.reg_read(arm.UC_ARM_REG_R1)
        pointer = uc.reg_read(arm.UC_ARM_REG_R2)
        count = uc.reg_read(arm.UC_ARM_REG_R3)
        args = self.words(pointer, count)
        path = bytes(uc.mem_read(args[0],128)).split(b'\0')[0].decode()
        path = '/' + path.lstrip('/')
        data = self.files.get(path)
        result = 0
        if command == 1:
            result = int(data is not None)
        elif command == 2:
            if data is None:
                self.files[path] = bytearray()
                result = 1
        elif command == 3:
            if data is not None:
                del self.files[path]
                result = 1
        elif command == 5:
            if data is None: result = -1
            else: self.write32(args[2], len(data))
        elif command == 6:
            if data is not None:
                chunk = bytes(data[args[2]:args[2]+args[3]])
                result = len(chunk)
                if chunk: uc.mem_write(args[1], chunk)
            self.reads.append((len(self.snapshots),path,args[2],args[3],result))
        elif command == 7:
            if data is not None:
                end = args[2] + args[3]
                if len(data) < end: data.extend(bytes(end - len(data)))
                data[args[2]:end] = uc.mem_read(args[1],args[3])
                result = args[3]
        else:
            raise AssertionError(f'unexpected file command {command}')
        uc.reg_write(arm.UC_ARM_REG_R0,result & 0xffffffff)

FIXTURE = r'''
#define main filemgr_original_main
#include "filemgr640.tc"
#undef main
void setString(char dst[], char src[]) { int i=0; while(src[i]!=0){dst[i]=src[i];i=i+1;}dst[i]=0; }
int main() {
    int guard = 0;
    activeStorage=1;initImagePalette();setString(cwd,"/");
    setString(selectedPath,"/head.bmp");setString(selectedRelPath,"head.bmp");
    if(validateSelectedImage()!=2)return 1;
    if(startImageCacheBuild()==0)return 2;
    mode=4;
    while(imageCacheActive!=0 && guard<10000){serviceImageCacheBuild();guard=guard+1;}
    if(imageCacheReady==0 || imageCacheError!=0)return 3;
    renderImageView();narm_yield();
    hitRight=1;applyImageViewInput();hitRight=0;renderImageView();narm_yield();
    hitZoomIn=1;applyImageViewInput();hitZoomIn=0;renderImageView();narm_yield();
    hitDown=1;applyImageViewInput();hitDown=0;renderImageView();narm_yield();
    hitOpen=1;applyImageViewInput();hitOpen=0;renderImageView();narm_yield();
    if(imageDrawError!=0)return 4;
    return 0;
}
'''

def trunc_div(value, divisor):
    return value // divisor if value >= 0 else -((-value) // divisor)

def verify(machine, width, height, seed):
    data = machine.files['/.fm_img.tmp']
    stride = (width + 1) // 2
    assert len(data) == 512 + stride * height
    assert data[12] == 2
    for y in range(height):
        for x in range(width):
            value = data[512 + y*stride + x//2]
            actual = value >> 4 if not (x & 1) else value & 15
            assert actual == scene(x,y,seed), ('cache pixel', x,y,actual)
    scale = min(640*256//width,298*256//height)
    center_x,center_y = width//2,height//2
    states = [(scale,center_x,center_y)]
    center_x = min(width-1,center_x+max(1,4096//scale));states.append((scale,center_x,center_y))
    scale = min(16384,scale*5//4);states.append((scale,center_x,center_y))
    center_y = min(height-1,center_y+max(1,4096//scale));states.append((scale,center_x,center_y))
    states.append((min(640*256//width,298*256//height),width//2,height//2))
    assert len(machine.snapshots) == len(states)
    for index,(pixels,(scale,cx,cy)) in enumerate(zip(machine.snapshots,states)):
        for y in range(70,368):
            sy = cy + trunc_div((y-219)*256,scale)
            for x in range(640):
                sx = cx + trunc_div((x-320)*256,scale)
                expected = 1 if sx<0 or sx>=width or sy<0 or sy>=height else scene(sx,sy,seed)
                assert pixels[y*640+x] == expected, ('viewport',index,x,y,pixels[y*640+x],expected)
    cache_reads = [read for read in machine.reads if read[1] == '/.fm_img.tmp']
    assert all(stage == 0 for stage,_,_,_,_ in cache_reads), 'pan/zoom must preserve source blocks'
    assert len(cache_reads) == (stride*height+4095)//4096
    assert sum(read[4] for read in cache_reads) == stride*height
    return len(cache_reads)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app',type=Path,default=ROOT.parents[1]/'MPC-2350_Firmware/programs/filemgr')
    parser.add_argument('--compiler',type=Path,default=ROOT.parents[1]/'Compiler_For_NARM/narmcc.exe')
    parser.add_argument('--deps',type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='filemgr_native_images_') as directory:
        directory = Path(directory)
        source = directory/'fixture.tc';source.write_text(FIXTURE)
        for level in (0,3):
            image = compile_source(args.compiler.resolve(),source,args.app.resolve(),directory/'fixture.narm',level)
            major,minor = struct.unpack_from('<HH',image,0x60)
            assert major == 1 and minor <= 13, 'existing firmware API must remain sufficient'
            for width,height,seed,bits,top_down in ((83,109,3,24,False),(17,9,7,32,True)):
                machine = ImageMachine(image,sample(width,height,seed,bits,top_down))
                machine.run()
                reads = verify(machine,width,height,seed)
                print(f'PASS O{level}: {width}x{height} BMP{bits}, packed pixels and 5 complete viewports; {reads} cold cache reads, zero pan/zoom reads')
    print('Native image streaming regression checks passed (mock firmware, not hardware timing).')

if __name__ == '__main__':
    main()
