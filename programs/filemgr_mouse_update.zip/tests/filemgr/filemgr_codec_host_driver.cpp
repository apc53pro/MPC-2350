#include <vector>
#define FILEMGR_CODEC_TEST_RGB
std::vector<unsigned char> capturedRgb;
int capturedWidth = 0;
void filemgrTestRgb(int x,int y,unsigned r,unsigned g,unsigned b) {
    int offset=(y*capturedWidth+x)*3;
    if(offset>=0 && offset+2<int(capturedRgb.size())){capturedRgb[offset]=r;capturedRgb[offset+1]=g;capturedRgb[offset+2]=b;}
}
#define FILEMGR_HOST_NO_MAIN
#include "filemgr_host_tests.cpp"
int main(int argc,char **argv) {
 try {
  test::setup();std::ifstream input(argv[1],std::ios::binary);
  std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(input)),{});
  std::string name=std::filesystem::path(argv[1]).filename().string();mock::addFile("/"+name,bytes);test::select(name);openSelected();
  if(mode!=4){std::cerr<<"NOT IMAGE mode="<<mode<<" status="<<statusCode<<" type="<<imageType<<" renderable="<<imageRenderable<<"\n";return 2;}
  capturedWidth=imageWidth;capturedRgb.assign(imageWidth*imageHeight*3,0);
  int steps=0;while(imageCacheActive && steps<10000000){serviceImageCacheBuild();++steps;}
  if(!imageCacheReady || imageCacheError){std::cerr<<"DECODE FAILED codec="<<imageCodecError<<" draw="<<imageDrawError<<" steps="<<steps<<" PNGpass="<<pngPass<<" row="<<pngRowY<<" inf="<<infState<<" produced="<<infProduced<<" pos="<<pngPosition<<" JPEGstage="<<jpegStage<<" scan="<<jpegScanNumber<<" mcu="<<jpegScanIndex<<" Ss="<<jpegSs<<" Se="<<jpegSe<<" Ah="<<jpegAh<<" Al="<<jpegAl<<" jpos="<<jpegPosition<<"\n";return 3;}
  auto* cache=mock::node(imageCachePath,activeStorage);test::require(cache,"Cache exists");
  std::ofstream output(argv[2],std::ios::binary);output.write(reinterpret_cast<const char*>(cache->bytes.data()),cache->bytes.size());
  if(argc>3){std::ofstream rgb(argv[3],std::ios::binary);rgb.write(reinterpret_cast<const char*>(capturedRgb.data()),capturedRgb.size());}
  unsigned long long readBytes=0;for(auto& call:mock::ioReads)readBytes+=call.returned;
  std::cout<<"OK "<<imageWidth<<"x"<<imageHeight<<" type="<<imageType<<" steps="<<steps<<" cache="<<cache->bytes.size()<<" reads="<<mock::ioReads.size()<<" bytes="<<readBytes<<"\n";
  return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
}
