#define FILEMGR_HOST_NO_MAIN
#include "filemgr_host_tests.cpp"

namespace mouse_test {
uint clockUs=1000;
void event(uint type,int x,int y,uint buttons=0,uint changed=0,int wheel=0) {
 clockUs+=1000;mock::mouseEvents.push_back({type,x,y,0,0,wheel,buttons,changed,clockUs});
 fmUpdateMouse();
}
void click(int x,int y,uint button=NARM_MOUSE_BUTTON_LEFT) {
 event(NARM_MOUSE_EVENT_PRESS,x,y,button,button);
 event(NARM_MOUSE_EVENT_RELEASE,x,y,0,button);
}
void fixture() {
 test::setup();fmMouseSuppressed=0;clockUs=1000;
 mock::addText("/a.txt","Alpha");mock::addText("/b.txt","Beta");mock::addDirectory("/folder");
 test::select("a.txt");dirty=1;render();
}
int rowY(const std::string& name) {test::select(name);return LIST_Y+(selectedIndex-scrollIndex)*ROW_H+3;}
void clean() {dirty=1;quickMoveDirty=0;render();}
void sameAsClean(const char* name) {auto before=mock::pixels;clean();test::require(before==mock::pixels,name);}
int actionRow(int action) {for(int i=0;i<fmMenuCount;++i)if(fmMenuActions[i]==action)return i;throw std::runtime_error("Missing menu action");}
void choose(int action) {int row=actionRow(action);click(fmMenuX+15,fmMenuY+24+row*15);}
void openMenu(const std::string& name) {int y=rowY(name);click(100,y,NARM_MOUSE_BUTTON_RIGHT);render();test::require(fmMenuOpen && fmMenuTarget==selectedIndex,"Right click selects the target and opens context menu");}
void navigation() {
 fixture();int by=rowY("b.txt");test::select("a.txt");clean();click(100,by);render();
 test::require(std::string(entryName)=="b.txt" && mode==0,"Single click selects without opening");sameAsClean("Mouse quick selection equals full browser framebuffer");
 click(100,by);test::require(mode==1 && std::string(fileViewName)=="b.txt","Double click opens selected file");
 event(NARM_MOUSE_EVENT_PRESS,100,200,NARM_MOUSE_BUTTON_BACK,NARM_MOUSE_BUTTON_BACK);test::require(mode==0,"Back button closes inspector");
 fixture();int fy=rowY("folder");click(100,fy);clockUs+=500000;click(100,fy);test::require(mode==0 && std::string(cwd)=="/","Slow clicks do not open");click(100,fy);test::require(std::string(cwd)=="/folder","Fast double click enters folder");
 click(30,55);test::require(std::string(cwd)=="/","UP path button returns to parent");
 auto storage=activeStorage;click(580,17);test::require(activeStorage!=storage,"Drive chip switches storage");
 fixture();for(int i=0;i<70;++i)mock::addText("/item"+std::to_string(i)+".txt","data");test::scan();clean();
 event(NARM_MOUSE_EVENT_WHEEL,100,180,0,0,-2);test::require(scrollIndex==6 && cacheStart==6,"Wheel scrolls three rows per detent");
 for(int i=0;i<10 && cacheLoading;++i)serviceVisibleCache();render();sameAsClean("Wheel scrolling repaints cache correctly");
 click(428,355);test::require(scrollIndex==entryCount-VISIBLE_ROWS,"Scrollbar click reaches last page");
 event(NARM_MOUSE_EVENT_PRESS,428,355,1,1);event(NARM_MOUSE_EVENT_MOVE,428,99,1);event(NARM_MOUSE_EVENT_RELEASE,428,99,0,1);test::require(scrollIndex==0,"Scrollbar drag reaches first page");
 fixture();auto clears=mock::clears,presents=mock::presents;event(NARM_MOUSE_EVENT_MOVE,150,170);render();test::require(mock::clears==clears && mock::presents==presents,"Cursor movement alone does not redraw app");
}
void menus() {
 fixture();openMenu("b.txt");test::require(fmMenuCount==9,"File menu includes open inspect rename delete and folder actions");
 test::require(fmMenuX>=0 && fmMenuY>=0 && fmMenuX+fmMenuWidth+3<=640 && fmMenuY+fmMenuHeight+3<=480,"Menu stays inside screen");
 auto clears=mock::clears;event(NARM_MOUSE_EVENT_MOVE,fmMenuX+10,fmMenuY+24+15);render();test::require(fmMenuHover==1 && mock::clears==clears,"Hover paints menu without clearing browser");sameAsClean("Menu hover framebuffer equals clean overlay");
 click(500,370);render();test::require(!fmMenuOpen && mode==0,"Outside click dismisses without opening underlying item");sameAsClean("Dismiss restores all covered pixels");
 openMenu("a.txt");choose(2);test::require(mode==1 && std::string(fileViewName)=="a.txt","Inspect explicitly opens hex viewer");
 fixture();openMenu("b.txt");choose(3);test::require(mode==2 && createMode==3 && std::string(editName)=="b.txt","Rename uses clicked item");click(220,267);test::require(mode==0 && mock::node("/b.txt",1),"Name editor Cancel is clickable");
 openMenu("b.txt");choose(4);test::require(fmMenuOpen && fmMenuCount==2 && mock::node("/b.txt",1),"Delete first opens confirmation and preserves file");choose(11);test::require(!fmMenuOpen && mock::node("/b.txt",1),"Delete cancel preserves file");
 openMenu("b.txt");choose(4);choose(10);test::require(!mock::node("/b.txt",1) && mock::node("/a.txt",1),"Confirmed delete removes only target file");
 fixture();openMenu("a.txt");fmMenuHover=0;clearHits();hitBack=1;applyInput();test::require(!fmMenuOpen && std::string(cwd)=="/","Escape/Back only closes menu");
 openMenu("a.txt");fmMenuHover=0;clearHits();hitDown=1;applyInput();test::require(fmMenuHover==1 && mode==0,"Menu consumes keyboard navigation");hitOpen=1;applyInput();test::require(mode==1,"Enter activates highlighted menu entry");
 fixture();click(639,479,NARM_MOUSE_BUTTON_RIGHT);render();test::require(fmMenuTarget<0 && fmMenuCount==5 && fmMenuX+fmMenuWidth+3<=640 && fmMenuY+fmMenuHeight+3<=480,"Blank-area menu is clipped and contains folder actions");choose(5);test::require(mode==2 && createMode==1,"Blank menu creates file");click(90,267);test::require(mode==0 && statusCode==6,"Name editor Save is clickable");
 fixture();openMenu("folder");test::require(fmMenuCount==8,"Folder menu excludes inspect bytes");choose(1);test::require(std::string(cwd)=="/folder","Menu opens directory");
 fixture();openMenu("a.txt");choose(4);int slot=selectedIndex-cacheStart;test::text(&cacheNames[slot*48],48,"other.txt");choose(10);test::require(mock::node("/a.txt",1),"Stale cached target cannot delete a different file");
 fixture();openMenu("a.txt");mock::events.push_back(NARM_EVENT_FOCUS_LOST);handleSystemEvents();test::require(!fmMenuOpen && !fmMouseGesture && fmMouseNeedsInit,"Focus loss cancels menus/gestures");
 fixture();openMenu("a.txt");event(NARM_MOUSE_EVENT_RESYNC,100,100,1);event(NARM_MOUSE_EVENT_PRESS,100,100,1,1);test::require(!fmMenuOpen && !fmMouseGesture,"Resync-held button is suppressed until release");event(NARM_MOUSE_EVENT_RELEASE,100,100,0,1);click(100,100);test::require(fmMouseGesture==0,"Mouse resumes after resync release");
 fixture();int y=rowY("a.txt");event(NARM_MOUSE_EVENT_PRESS,100,y,1,1);event(NARM_MOUSE_EVENT_DISCONNECT,100,y);test::require(!fmMouseGesture && fmMouseLastRow<0,"Disconnect cancels double click/drag");
}
void edgeCases() {
 fixture();mock::mouseState.flags = 0;event(NARM_MOUSE_EVENT_PRESS,100,100,1,1);
 clearHits();hitDown=1;applyInput();test::require(selectedIndex==1 && mode==0,"Keyboard remains usable without a connected mouse");
 fixture();int y=rowY("a.txt");click(100,y);event(NARM_MOUSE_EVENT_PRESS,100,y,1,1);event(NARM_MOUSE_EVENT_MOVE,130,y,1);event(NARM_MOUSE_EVENT_MOVE,100,y,1);event(NARM_MOUSE_EVENT_RELEASE,100,y,0,1);
 test::require(mode==0 && fmMouseLastRow<0,"Drag out-and-back does not count as double click");
 fixture();openMenu("a.txt");int row=actionRow(3);event(NARM_MOUSE_EVENT_PRESS,fmMenuX+10,fmMenuY+24+row*15,1,1);event(NARM_MOUSE_EVENT_RELEASE,fmMenuX+10,fmMenuY+24+(row+1)*15,0,1);
 test::require(mode==0 && fmMenuOpen,"Menu press and release on different rows does not activate");
 fixture();openMenu("a.txt");mock::now+=1000;audioPanelDirty=1;render();sameAsClean("Audio panel refresh preserves menu overlay");
 fixture();openMenu("a.txt");clearHits();hitStorage=1;applyInput();test::require(!fmMenuOpen && activeStorage==1,"Menu keyboard dismissal cannot switch drive underneath it");
 fixture();mode=4;imageWidth=1000;imageHeight=800;imageCenterX=500;imageCenterY=400;imageScale=256;imageCacheReady=1;imageCacheError=0;
 event(NARM_MOUSE_EVENT_PRESS,300,200,1,1);event(NARM_MOUSE_EVENT_RELEASE,340,220,0,1);
 test::require(imageCenterX==460 && imageCenterY==380,"Release event includes the final drag position");
}
void viewers() {
 fixture();mode=4;imageWidth=1000;imageHeight=800;imageCenterX=500;imageCenterY=400;imageScale=256;imageCacheReady=1;imageCacheError=0;
 event(NARM_MOUSE_EVENT_PRESS,300,200,1,1);event(NARM_MOUSE_EVENT_MOVE,340,220,1);event(NARM_MOUSE_EVENT_RELEASE,340,220,0,1);
 test::require(imageCenterX==460 && imageCenterY==380 && !fmMouseGesture,"Image drag pans in source coordinates");
 auto scale=imageScale;event(NARM_MOUSE_EVENT_WHEEL,300,200,0,0,1);test::require(imageScale>scale,"Wheel zooms image in");
 event(NARM_MOUSE_EVENT_WHEEL,300,200,0,0,-1);test::require(imageScale==scale,"Wheel zooms image out");
 fixture();mock::addText("/long.txt",std::string(900,'A'));test::select("long.txt");openSelected();serviceFileViewLoad();event(NARM_MOUSE_EVENT_WHEEL,200,200,0,0,-2);test::require(viewOffset==256,"Wheel pages file inspector");
 fixture();mock::addFile("/audio.wav",mock::wav());test::select("audio.wav");openSelected();mock::now+=1000;serviceAudio();click(30,400);test::require(audioPaused,"Mouse pauses playback");click(278,407);test::require(mock::position==mock::total/2,"Mouse seeks on audio progress bar: pos="+std::to_string(mock::position)+" total="+std::to_string(mock::total)+" app="+std::to_string(audioTotalFrames));
}
}
int main(int argc,char**argv) {
 try {
  mouse_test::navigation();mouse_test::menus();mouse_test::viewers();mouse_test::edgeCases();
  if(argc>1){mouse_test::fixture();mouse_test::openMenu("a.txt");mock::bitmap(std::filesystem::path(argv[1])/"mouse-context-menu.bmp");}
  std::cout<<"PASS: "<<test::checks<<" mouse assertions; selection, double click, wheel/scrollbar, context actions, confirmation, focus/resync, viewers and audio.\n";
 } catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}


