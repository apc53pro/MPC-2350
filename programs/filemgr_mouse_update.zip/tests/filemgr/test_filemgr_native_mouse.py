"""Execute real FILEMGR mouse API calls, menus and click navigation as Thumb code.

Mocks the existing NARM mouse 1.0 get_interface/table ABI and VGA4 callbacks.
No firmware code, compiler builtins or ABI changes are introduced.
"""
from pathlib import Path
import argparse,tempfile,struct
from collections import deque
from test_filemgr_native_graphics import NativeVideo,compile_source,compare,arm,CONTEXT,API,STUB
ROOT=Path(__file__).resolve().parent

FIXTURE=r'''
#define main filemgr_original_main
#include "filemgr640.tc"
#undef main
void mouseFixtureString(char dst[],char src[]){int i=0;while(src[i]!=0){dst[i]=src[i];i=i+1;}dst[i]=0;}
void mouseFixtureBrowser(){
 mouseFixtureString(cwd,"/");activeStorage=1;mode=0;scanDone=1;scanActive=0;cacheLoading=0;
 entryCount=2;cacheStart=0;scrollIndex=0;selectedIndex=0;
 cacheStatuses[0]=1;cacheStatuses[1]=1;cacheTypes[0]=0;cacheTypes[1]=0;
 cacheLens[0]=5;cacheLens[1]=5;mouseFixtureString(cacheNames,"a.txt");mouseFixtureString(&cacheNames[48],"b.txt");
 selectedInfoDirty=0;selectedInfoValid=0;dirty=1;
}
int main(){
 int i;
 mouseFixtureBrowser();render();narm_yield();
 fmUpdateMouse();if(selectedIndex!=1 || mode!=0)return 1;render();narm_yield();
 /* Double click invokes the existing file inspector, backed by mocked file API. */
 fmUpdateMouse();if(mode!=1)return 2;render();narm_yield();
 mouseFixtureBrowser();fmUpdateMouse();if(fmMenuOpen==0 || fmMenuTarget!=1)return 3;render();narm_yield();
 fmUpdateMouse();if(fmMenuHover!=1)return 4;render();narm_yield();
 dirty=1;render();narm_yield();
 fmUpdateMouse();if(fmMenuOpen!=0)return 5;render();narm_yield();
 dirty=1;render();narm_yield();
 fmUpdateMouse();if(fmMenuOpen==0)return 6;render();narm_yield();
 fmUpdateMouse();if(fmMenuCount!=2 || fmMenuActions[0]!=10)return 7;render();narm_yield();
 fmUpdateMouse();if(fmMenuOpen!=0)return 8;render();narm_yield();
 fmUpdateMouse();if(fmMenuOpen!=0 || fmMouseGesture!=0)return 9;narm_yield();
 mode=0;entryCount=60;selectedIndex=0;scrollIndex=0;fmUpdateMouse();
 if(scrollIndex!=3 || cacheStart!=3)return 10;narm_yield();
 mode=4;imageWidth=1000;imageHeight=800;imageCenterX=500;imageCenterY=400;imageScale=256;imageCacheReady=1;imageCacheError=0;
 fmUpdateMouse();if(imageCenterX!=460 || imageCenterY!=380 || fmMouseGesture!=0)return 11;narm_yield();
 fmUpdateMouse();if(imageScale!=320)return 12;narm_yield();
 fmMenuOpen=1;fmMouseGesture=3;fmResetMouse();if(fmMenuOpen!=0 || fmMouseGesture!=0)return 13;
 return 0;
}
'''
def event(t,x,y,buttons=0,changed=0,wheel=0,timestamp=0):return (t,x,y,0,0,wheel,buttons,changed,timestamp)
def click(x,y,button=1,t=1000):return [event(2,x,y,button,button,timestamp=t),event(4,x,y,0,button,timestamp=t+1000)]
class NativeMouse(NativeVideo):
 def __init__(self,image):
  super().__init__(image)
  self.write32(API+28,STUB+0x81)
  self.write32(CONTEXT+0x400,32)
  self.write32(CONTEXT+0x404,1)
  for offset,stub in ((8,0x90),(12,0xa0),(20,0xb0),(24,0xc0)):
   self.write32(CONTEXT+0x400+offset,STUB+stub+1)
  self.write32(CONTEXT+64,CONTEXT+0x300);self.write32(CONTEXT+0x300,12);self.write32(CONTEXT+0x308,STUB+0x71)
  self.phases={1:click(100,114),2:click(100,114,t=10000),3:click(100,114,2),4:[event(1,110,153)],6:click(500,370),8:click(100,114,2),9:click(110,114+24+3*15),10:click(110,114+24+15),11:[event(64,100,100,1),event(2,100,100,1,1),event(4,100,100,0,1)],12:[event(8,100,200,wheel=-1)],13:[event(2,300,200,1,1),event(1,340,220,1),event(4,340,220,0,1)],14:[event(8,300,200,wheel=1)]}
  self.phase=-1;self.events=deque();self.mouse_calls=[]
 def callback(self,uc,address,size,user):
  if address==STUB and uc.reg_read(arm.UC_ARM_REG_R1)==9:
   uc.reg_write(arm.UC_ARM_REG_R0,1);return
  if address==STUB+0x80:
   args=[uc.reg_read(r) for r in (arm.UC_ARM_REG_R1,arm.UC_ARM_REG_R2,arm.UC_ARM_REG_R3)]
   assert args==[0x101,1,0],('mouse get_interface',args)
   uc.reg_write(arm.UC_ARM_REG_R0,CONTEXT+0x400);return
  if address in (STUB+0x90,STUB+0xa0,STUB+0xb0,STUB+0xc0):
   pointer=uc.reg_read(arm.UC_ARM_REG_R1);self.mouse_calls.append(address)
   if address==STUB+0x90:
    phase=len(self.snapshots)
    if phase!=self.phase:self.phase=phase;self.events=deque(self.phases.get(phase,[]))
    uc.mem_write(pointer,struct.pack('<iiII',100,100,0,3));result=0
   elif address==STUB+0xa0:
    result=bool(self.events)
    if result:
     e=self.events.popleft();uc.mem_write(pointer,struct.pack('<IiiiiiIII',*e))
   else:assert pointer in (0,1);result=0
   uc.reg_write(arm.UC_ARM_REG_R0,int(result));return
  if address==STUB+0x70:
   cmd=uc.reg_read(arm.UC_ARM_REG_R1);args=self.words(uc.reg_read(arm.UC_ARM_REG_R2),uc.reg_read(arm.UC_ARM_REG_R3));result=0
   if cmd==5:self.write32(args[2],4)
   elif cmd==6:uc.mem_write(args[1],b'Test'[:args[3]]);result=min(4,args[3])
   elif cmd!=1:raise AssertionError(('unexpected file command',cmd))
   uc.reg_write(arm.UC_ARM_REG_R0,result);return
  return super().callback(uc,address,size,user)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--app',type=Path,default=ROOT.parents[1]/'MPC-2350_Firmware/programs/filemgr')
 parser.add_argument('--compiler',type=Path,default=ROOT.parents[1]/'Compiler_For_NARM/narmcc.exe')
 parser.add_argument('--deps',type=Path)
 parser.add_argument('--workdir',type=Path)
 args=parser.parse_args()
 def run(work):
  source=work/'mouse.tc';source.write_text(FIXTURE)
  for level in (0,3):
   image=compile_source(args.compiler.resolve(),source,args.app.resolve(),work/f'mouse_O{level}.narm',level)
   assert struct.unpack_from('<HH',image,0x60)==(1,13),'Mouse imports must require existing firmware API 1.13'
   machine=NativeMouse(image)
   try:machine.run()
   except Exception:print('native mouse result',machine.uc.reg_read(arm.UC_ARM_REG_R0),'frames',len(machine.snapshots));raise
   compare(machine.snapshots[4],machine.snapshots[5],f'O{level} menu hover vs clean')
   compare(machine.snapshots[6],machine.snapshots[7],f'O{level} menu dismissal vs clean')
   assert len(machine.snapshots)==15 and machine.mouse_calls
   print(f'PASS O{level}: actual mouse v1.0 ABI, click/double click, context hover/dismiss/delete cancel, resync, scrolling, image dragging/zoom and 2 full-frame comparisons')
 if args.workdir:args.workdir.mkdir(parents=True,exist_ok=True);run(args.workdir.resolve())
 else:
  with tempfile.TemporaryDirectory(prefix='filemgr_mouse_') as directory:run(Path(directory))
if __name__=='__main__':main()

