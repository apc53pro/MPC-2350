"""Host checks of extracted firmware functions plus explicitly static contracts.

This does not emulate RP2350 exceptions, SD hardware or I2S. The generated C++
executes the real spawn-completion, process-finish, command queue and audio
snapshot bodies with small host fixtures. A separate static check verifies
that the service yields and the scheduler clears native context before loading.
"""

import argparse
from pathlib import Path
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent
FIRMWARE = ROOT.parent / "firmware" / "resource_development"
if not FIRMWARE.is_dir():
    FIRMWARE = ROOT.parents[1] / "resource_development"


def block(source: str, marker: str) -> str:
    start = source.index(marker)
    opening = source.index("{", start)
    depth = 1
    cursor = opening + 1
    while depth:
        if source[cursor] == "{":
            depth += 1
        elif source[cursor] == "}":
            depth -= 1
        cursor += 1
    return source[start:cursor]


def declaration(source: str, marker: str) -> str:
    return block(source, marker) + ";\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compiler", default="g++", help="C++17 compiler executable")
    args = parser.parse_args()
    runtime = (FIRMWARE / "native_runtime.cpp").read_text(encoding="utf-8")
    audio = (FIRMWARE / "audio_runtime.cpp").read_text(encoding="utf-8")
    audio_header = (FIRMWARE / "audio_runtime.h").read_text(encoding="utf-8")

    # These are static source contracts, not claims of hardware behavior.
    spawn_service = block(runtime, "case NARM_SERVICE_SPAWN_PROGRAM:\n    {")
    assert "narm_arch_yield(NARM_ARCH_SWITCH_YIELD)" in spawn_service
    assert "native_run_sd" not in spawn_service and "native_run_fs" not in spawn_service
    assert spawn_service.index("spawn_requested = true") < spawn_service.index("narm_arch_yield")
    scheduler = block(runtime, "void native_scheduler_poll()")
    spawn_completion = block(scheduler, "if (selected->spawn_requested)")
    assert scheduler.index("narm_arch_resume") < scheduler.index("(NativeProcess *)nullptr, __ATOMIC_RELEASE)")
    assert scheduler.index("(NativeProcess *)nullptr, __ATOMIC_RELEASE)") < scheduler.index("if (selected->spawn_requested)")
    assert scheduler.index("if (selected->spawn_requested)") < scheduler.index("if (selected->state == NATIVE_PROCESS_RUNNING)")
    ownership = block(runtime, "auto claim_voice =")
    assert "owner && owner != process" in ownership
    assert "!audio_command_queue_idle() || voice_channel_active" in ownership
    audio_submit = block(runtime, "int32_t native_audio_submit(")
    stop = audio_submit[audio_submit.index("case NARM_AUDIO_STOP_VOICE:"):audio_submit.index("case NARM_AUDIO_STOP_ALL:")]
    assert stop.index("audio_voice_owners[args[0]] != process") < stop.index("stop_voice_channel")
    query = block(audio_submit, "case NARM_AUDIO_POSITION:")
    assert query.index("audio_voice_owners[args[0]] != process") < query.index("audio_get_voice_position")
    assert "if (!audio_command_queue_idle()) return NARM_SERVICE_ERR_BUSY" in query
    commands = block(audio, "static void processAudioCommands()")
    assert commands.index("refreshActiveVoiceMask();") < commands.index("atomicStoreRelease(&g_commandAppliedIndex")
    idle = block(audio, "bool audio_command_queue_idle()")
    assert "g_commandAppliedIndex" in idle and "g_commandReadIndex" not in idle

    native_fixture = r'''
#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
using String = std::string;
enum NativeProcessState { NATIVE_PROCESS_EMPTY, NATIVE_PROCESS_LOADING,
 NATIVE_PROCESS_READY, NATIVE_PROCESS_RUNNING, NATIVE_PROCESS_WAITING,
 NATIVE_PROCESS_SUSPENDED, NATIVE_PROCESS_EXITED, NATIVE_PROCESS_FAULTED };
using NarmStatus = int32_t;
constexpr uint32_t NARM_MAX_PROCESSES = 4;
constexpr NarmStatus NARM_OK = 0;
constexpr int32_t NARM_SERVICE_ERR_BUSY = -4;
struct NativeProcess {
 uint32_t pid = 0, parent_pid = 0, launch_storage = 0;
 NativeProcessState state = NATIVE_PROCESS_EMPTY;
 bool focused = false, spawn_requested = false;
 int32_t exit_status = 0, spawn_result = 0;
 char launch_path[256]{};
 uint32_t data_sentinel = 0;
};
NativeProcess processes[4];
NativeProcess *focused_process = nullptr;
int32_t last_exit_status = 0;
int audio_releases = 0, graphics_releases = 0, process_releases = 0;
int loader_calls = 0, sd_loads = 0;
NarmStatus loader_result = NARM_OK;
struct SerialStub {
 template<class T> void print(T) {}
 template<class T> void println(T) {}
} Serial;
void native_audio_release(NativeProcess &) { ++audio_releases; }
void native_graphics_release() { ++graphics_releases; }
void set_process_focus(NativeProcess *next) {
 if (focused_process) focused_process->focused = false;
 focused_process = next;
 if (next) { next->focused = true;
   if(next->state == NATIVE_PROCESS_SUSPENDED) next->state = NATIVE_PROCESS_READY; }
}
void release_process(NativeProcess &process) { process = {}; ++process_releases; }
NarmStatus fixture_load(const String &path, bool sd) {
 ++loader_calls; sd_loads += sd;
 assert(path == "/child.narm");
 if(loader_result != NARM_OK) return loader_result;
 processes[1].pid = 0x102;
 processes[1].state = NATIVE_PROCESS_READY;
 set_process_focus(&processes[1]);
 return NARM_OK;
}
NarmStatus native_run_sd(const String &path) { return fixture_load(path,true); }
NarmStatus native_run_fs(const String &path) { return fixture_load(path,false); }
void finish_process(NativeProcess &,int32_t);
void fixture_reset() {
 for(auto &process : processes) process = {};
 focused_process = nullptr;
 audio_releases = graphics_releases = process_releases = 0;
 loader_calls = sd_loads = 0; loader_result = NARM_OK;
}
'''
    native_fixture += block(runtime, "void finish_process(NativeProcess &process, int32_t status)")
    native_fixture += "\nvoid complete_spawn(NativeProcess *selected) {\n" + spawn_completion + "\n}\n"

    audio_fixture = r'''
constexpr uint8_t AUDIO_VOICE_CHANNELS = 8;
constexpr uint32_t AUDIO_OUTPUT_SAMPLE_RATE = 48000;
constexpr uint32_t kCommandQueueLength = 16;
struct StereoFrame { int16_t left, right; };
'''
    for marker in ("enum class AudioCommandType", "struct AudioCommand", "enum class VoiceSource", "struct MixerVoice", "struct VoicePositionSnapshot"):
        audio_fixture += declaration(audio, marker)
    audio_fixture += declaration(audio_header, "struct AudioVoicePosition")
    audio_fixture += r'''
MixerVoice g_voices[AUDIO_VOICE_CHANNELS]{};
VoicePositionSnapshot g_voicePositions[AUDIO_VOICE_CHANNELS]{};
AudioCommand g_commandQueue[kCommandQueueLength]{};
volatile uint32_t g_commandReadIndex = 0, g_commandWriteIndex = 0, g_commandAppliedIndex = 0;
volatile uint32_t g_activeVoiceMask = 0, g_pausedVoiceMask = 0;
bool audio_runtime_ready() { return true; }
'''
    for marker in ("static inline uint32_t atomicLoadAcquire", "static inline uint32_t atomicLoadRelaxed", "static inline void atomicStoreRelease", "static bool enqueueCommand", "static bool dequeueCommand", "static void refreshActiveVoiceMask()", "static void resetMixerVoice", "static void processAudioCommands()", "bool audio_get_voice_position(", "bool audio_command_queue_idle()"):
        audio_fixture += block(audio, marker) + "\n"

    checks = r'''
int main() {
 // Real completion body preserves parent and correctly reports storage/PID.
 fixture_reset();
 auto &parent = processes[0];
 parent.pid = 0x101; parent.state = NATIVE_PROCESS_RUNNING;
 parent.data_sentinel = 0xc0ffee; parent.spawn_requested = true;
 std::strcpy(parent.launch_path,"/child.narm");
 set_process_focus(&parent);
 complete_spawn(&parent);
 assert(loader_calls == 1 && sd_loads == 0 && !parent.spawn_requested);
 assert(parent.spawn_result == 0x102 && processes[1].parent_pid == 0x101);
 assert(parent.pid == 0x101 && parent.data_sentinel == 0xc0ffee);
 assert(process_releases == 0 && focused_process == &processes[1]);
 parent.state = NATIVE_PROCESS_SUSPENDED;
 finish_process(processes[1],0);
 assert(focused_process == &parent && parent.state == NATIVE_PROCESS_READY);
 assert(parent.data_sentinel == 0xc0ffee && process_releases == 1);
 assert(audio_releases == 1 && graphics_releases == 1);

 // Failed child load leaves parent focused and returns exact loader error.
 parent.spawn_requested = true; parent.launch_storage = 1;
 loader_result = -17;
 complete_spawn(&parent);
 assert(parent.spawn_result == -17 && focused_process == &parent);
 assert(sd_loads == 1 && process_releases == 1);

 // Generation mismatch must not focus a new process reusing parent slot.
 fixture_reset();
 processes[0].pid = 0x201; processes[0].state = NATIVE_PROCESS_SUSPENDED;
 processes[1].pid = 0x102; processes[1].parent_pid = 0x101;
 processes[1].state = NATIVE_PROCESS_READY; set_process_focus(&processes[1]);
 finish_process(processes[1],0);
 assert(focused_process == nullptr);

 // Unfocused child exiting must preserve another application's focus.
 fixture_reset();
 processes[0].pid = 0x101; processes[0].state = NATIVE_PROCESS_READY;
 processes[1].pid = 0x102; processes[1].parent_pid = 0x101;
 processes[1].state = NATIVE_PROCESS_READY;
 processes[2].pid = 0x103; processes[2].state = NATIVE_PROCESS_READY;
 set_process_focus(&processes[2]); finish_process(processes[1],0);
 assert(focused_process == &processes[2] && graphics_releases == 0);

 // Dequeue is not an application acknowledgement. This catches stale
 // position/EOF results between dequeuing and publishing a mixer snapshot.
 AudioCommand play{}; play.type = AudioCommandType::PlaySd;
 play.voiceChannel = 0; play.sampleRate = 44100;
 play.startFrame = 88200; play.totalFrames = 441000;
 assert(enqueueCommand(play)); assert(!audio_command_queue_idle());
 AudioCommand removed{}; assert(dequeueCommand(removed));
 assert(g_commandReadIndex == g_commandWriteIndex);
 assert(!audio_command_queue_idle());
 processAudioCommands(); assert(audio_command_queue_idle());

 // Real command processing publishes absolute seek position and total.
 assert(enqueueCommand(play)); processAudioCommands();
 assert(audio_command_queue_idle());
 AudioVoicePosition position{};
 assert(audio_get_voice_position(0,position));
 assert(position.active && !position.paused);
 assert(position.current_frame == 88200 && position.total_frames == 441000);
 assert(position.sample_rate == 44100);
 g_pausedVoiceMask = 1;
 assert(audio_get_voice_position(0,position) && position.paused);
 assert(position.current_frame == 88200);
 AudioCommand stop{}; stop.type = AudioCommandType::Stop;
 stop.voiceChannel = 0;
 assert(enqueueCommand(stop)); assert(!audio_command_queue_idle());
 processAudioCommands(); assert(audio_command_queue_idle());
 assert(audio_get_voice_position(0,position));
 assert(!position.active && position.current_frame == 0 && position.total_frames == 0);

 // A replacement command immediately followed by another seek publishes
 // only the final command's metadata before acknowledging the queue.
 assert(enqueueCommand(play)); play.startFrame = 220500;
 assert(enqueueCommand(play)); processAudioCommands();
 assert(audio_command_queue_idle() && audio_get_voice_position(0,position));
 assert(position.current_frame == 220500 && position.total_frames == 441000);
 assert(!audio_get_voice_position(8,position));
 std::cout << "host extracted-function checks passed\n";
}
'''
    with tempfile.TemporaryDirectory(prefix="runtime-host-", dir=ROOT) as temporary:
        directory = Path(temporary)
        source = directory / "runtime_checks.cpp"
        executable = directory / "runtime_checks.exe"
        source.write_text(native_fixture + audio_fixture + checks, encoding="utf-8")
        subprocess.run([args.compiler, "-std=c++17", "-O2", str(source), "-o", str(executable)], check=True)
        subprocess.run([str(executable)], check=True)
    print("static service/scheduler ordering and voice ownership contracts passed")


if __name__ == "__main__":
    main()
