# FILEMGR mouse and context menu update

Built November 2, 2026. Replace the device's filemgr.narm and restart FILEMGR.
This build uses the **existing NARM mouse v1.0 interface (firmware API 1.13)**.
No compiler/firmware/ABI changes were made. The firmware owns the cursor.

## Mouse controls

- Left click selects. Double click within 400 ms opens a folder/file, launches
  a NARM program or plays a WAV through the existing actions.
- Right click selects the clicked item and opens a compact 5x7-font context
  menu: Open/Run/Play, Inspect Bytes (files), Rename, Delete, New File,
  New Folder, Refresh, Parent Folder and Switch Flash/SD.
- Delete opens a separate confirmation menu; **Cancel is selected by default**.
  No deletion occurs until Delete Permanently is chosen. Menu actions bind to
  the original storage/directory/entry/name and reject stale cached targets.
- Hover highlights menu entries. Press and release on the same row activate.
  Outside click or Escape/Backspace dismiss without clicking through. Menus
  also accept Up/Down and Enter.
- Wheel scrolls three rows per detent. Click/drag the narrow list scrollbar.
  Click UP at the left of the path bar for parent/back; click the drive chip
  at the top right to switch Flash/SD.
- Image viewer: drag with the left button to pan; wheel to zoom.
- File inspector: wheel pages through bytes. Mouse Back returns to files/parent.
- Audio panel: click play/pause or the timeline. Name editor: click Save/Cancel.

Cursor movement alone does not repaint FILEMGR. Hover repaints only the menu;
closing the overlay restores the underlying screen. Background audio/storage
redraws preserve the menu. Focus loss, disconnect and queue RESYNC cancel
pending gestures. Held buttons after RESYNC are suppressed until released.
Keyboard controls work when no mouse is connected.

## Validation and resources

- 111 mouse host assertions covering navigation, menus/actions/confirmation,
  stale targets, keyboard-only operation, focus/disconnect/resync, viewport
  restoration, dragging and audio/name-editor controls.
- Real Thumb code at O0/O3 calls the existing get_interface(0x0101,1,0) and
  mouse table callbacks; tests click/double-click, context hover/dismiss/delete
  cancel, resync, scroll, image drag/zoom and compare complete framebuffers.
- Existing 151 host assertions, 46 UI framebuffer comparisons, 683 image
  streaming assertions, 41 codec runtime assertions, 92 PNG/102 JPEG reference
  fixtures and 12 malformed-input cases pass. Existing native BMP, PNG/JPEG
  and graphics regressions pass.
- Binary: 161,299 bytes. Static app data: 121,068 bytes
  (544 bytes more than the previous build).
  Existing bounded image caches and decoding limits remain in place.
- Tested with mocked mouse/storage/video and actual generated instructions.
  Physical mouse hardware has not been tested in this chat.

The project layout now uses MPC-2350_Firmware/programs/filemgr and tests/filemgr.
Build/test paths were updated accordingly, including the app build script's
compiler path. Installed source is rebuilt and compared by SHA-256 to the
included binary.

SHA-256: 32cef4bd9a8a4a46888172d1523393ef00c7899a761b588f6262a999d06ad26a
