"""Build PACMAN.narm with Arm GNU Toolchain and the project's narm_image.py."""
import argparse
import json
import os
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

TEXT_BASE = 0x10000000
DATA_BASE = 0x20000000
LINKER_SCRIPT = """
ENTRY(main)
SECTIONS {
  . = 0x10000000;
  .text : { *(.text .text.*) }
  . = 0x20000000;
  .narm_data : {
    *(.got.plt)
    *(.got)
    _narm_got_end = .;
    *(.rodata .rodata.*)
    *(.data .data.*)
  }
  .bss (NOLOAD) : {
    *(.bss .bss.*)
    *(COMMON)
    _narm_bss_end = .;
  }
  /DISCARD/ : { *(.ARM.exidx* .ARM.extab* .comment .note*) }
}
"""

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--toolchain", type=Path, required=True, help="Arm GNU Toolchain bin directory")
    parser.add_argument("--image-tool", type=Path, required=True, help="Compiler_For_NARM/tools/narm_image.py")
    parser.add_argument("--output", type=Path, default=Path("PACMAN.narm"))
    parser.add_argument("--source", type=Path, default=Path(__file__).with_name("pacman.tc"))
    parser.add_argument("--symbols", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    source_dir = Path(__file__).resolve().parent

    def run(tool, *cmd, capture=False):
        binary = args.toolchain / ("arm-none-eabi-" + tool)
        if binary.with_suffix(".exe").is_file():
            binary = binary.with_suffix(".exe")
        build_env = dict(os.environ, TMP=str(stage), TEMP=str(stage), TMPDIR=str(stage))
        return subprocess.run([str(binary), *map(str, cmd)], check=True, text=True,
                              capture_output=capture, env=build_env).stdout

    with tempfile.TemporaryDirectory(prefix="pacman-build-", dir=source_dir) as temp:
        stage = Path(temp)
        linker = stage / "pacman.ld"
        linker.write_text(LINKER_SCRIPT)
        driver = stage / "pacman.c"
        driver.write_text('#include "narm_gcc.h"\n#include "pacman.tc"\n')
        # A separately selected source can be used for test probes.
        (stage / "pacman.tc").write_bytes(args.source.read_bytes())
        elf = stage / "pacman.elf"
        run("gcc", "-O3", "-std=c11", "-mcpu=cortex-m33", "-mthumb", "-mfloat-abi=soft",
            "-fsigned-char", "-DPACMAN_GCC", "-fPIC", "-msingle-pic-base", "-mpic-register=r9",
            "-mno-pic-data-is-text-relative", "-fno-builtin", "-fno-unwind-tables",
            "-fno-asynchronous-unwind-tables", "-ffunction-sections", "-fdata-sections",
            "-I", source_dir, "-nostdlib", "-Wl,--gc-sections", "-T", linker, driver, "-o", elf)
        symbols = {}
        for line in run("nm", "--defined-only", elf, capture=True).splitlines():
            address, _, name = line.split()
            symbols[name] = int(address, 16)

        text = stage / "text.bin"
        data = stage / "data.bin"
        run("objcopy", "--dump-section", f".text={text}", "--dump-section", f".narm_data={data}", elf)
        payload = bytearray(data.read_bytes())
        bss_end = symbols["_narm_bss_end"]
        if symbols["_GLOBAL_OFFSET_TABLE_"] != DATA_BASE:
            raise ValueError("GOT must start at the NARM data base")
        bss_bytes = bss_end - ((DATA_BASE + len(payload) + 3) & ~3)
        if args.symbols:
            args.symbols.write_text(json.dumps({name: value - DATA_BASE for name, value in symbols.items()
                                                if DATA_BASE <= value < bss_end}))
        relocations = []
        for offset in range(0, symbols["_narm_got_end"] - DATA_BASE, 4):
            target, = struct.unpack_from("<I", payload, offset)
            if not target:
                continue
            if not DATA_BASE <= target < bss_end:
                raise ValueError(f"Unexpected GOT entry at {offset:#x}: {target:#x}")
            relocations.append({"type": "data_ptr32", "patch_data_offset": offset,
                                "target_addend": target - DATA_BASE})
            struct.pack_into("<I", payload, offset, 0)
        data.write_bytes(payload)

        manifest = stage / "pacman.json"
        manifest.write_text(json.dumps({
            "name": "PACMAN", "text_file": text.name, "data_file": data.name,
            "entry_text_offset": symbols["main"] - TEXT_BASE,
            "bss_bytes": bss_bytes, "stack_bytes": 8192, "heap_bytes": 4096,
            "api_minor": 11, "capabilities_low": 15,
            "imports": [{"service_id": x} for x in (0, 1, 0x100, 0x300, 0x400, 0x700)],
            "relocations": relocations,
        }))
        subprocess.run([sys.executable, str(args.image_tool), "build", str(manifest),
                        "-o", str(args.output)], check=True)

if __name__ == "__main__":
    main()
