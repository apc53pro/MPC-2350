#include <stdint.h>
#include <stddef.h>
#include "narm.tch"

typedef unsigned uint;
int scatter_chase_phase(void);

// GCC lowers larger state copies to memcpy even in a freestanding build.
typedef unsigned NarmCopyWord __attribute__((may_alias));
void *memcpy(void *restrict dest, const void *restrict src, size_t count) {
    unsigned char *out = dest;
    const unsigned char *in = src;
    if ((((uintptr_t)out | (uintptr_t)in) & 3) == 0) {
        while (count >= sizeof(NarmCopyWord)) {
            *(NarmCopyWord *)out = *(const NarmCopyWord *)in;
            out += sizeof(NarmCopyWord);
            in += sizeof(NarmCopyWord);
            count -= sizeof(NarmCopyWord);
        }
    }
    while (count--) *out++ = *in++;
    return dest;
}

typedef struct NarmContext NarmContext;
typedef int (*NarmSubmit)(NarmContext *, unsigned, const unsigned *, unsigned);

struct NarmApi {
    unsigned header[4];
    NarmSubmit invoke;
    void (*yield)(NarmContext *, unsigned);
    void (*exit)(NarmContext *, int);
};

struct NarmKeyboard {
    unsigned header[2];
    int (*key_down)(NarmContext *, unsigned);
};

struct NarmVideo {
    unsigned header_and_direct_calls[7];
    NarmSubmit submit;
};

struct NarmAudio {
    unsigned header[2];
    unsigned (*status)(NarmContext *);
    NarmSubmit submit;
};

struct NarmFile {
    unsigned header[2];
    NarmSubmit submit;
};

struct NarmContext {
    unsigned header[2];
    const struct NarmApi *api;
    unsigned process_and_memory[7];
    volatile unsigned *yield_requested;
    unsigned capabilities[2];
    const struct NarmKeyboard *keyboard;
    const struct NarmVideo *video;
    const struct NarmAudio *audio;
    const struct NarmFile *file;
};

_Static_assert(offsetof(struct NarmContext, yield_requested) == 40, "NARM control offset");
_Static_assert(offsetof(struct NarmContext, file) == 64, "NARM file offset");
_Static_assert(offsetof(struct NarmVideo, submit) == 28, "NARM video offset");
_Static_assert(offsetof(struct NarmAudio, submit) == 12, "NARM audio offset");

register NarmContext *narm_context __asm__("r10");

static inline void pacman_poll(void) {
    if (*narm_context->yield_requested) narm_context->api->yield(narm_context, 0);
}

// Keep the main clock call site distinct from audio polling.
__attribute__((noinline)) unsigned narm_millis(void) {
    return narm_context->api->invoke(narm_context, 1, 0, 0);
}

unsigned narm_micros(void) {
    return narm_context->api->invoke(narm_context, 2, 0, 0);
}

void narm_exit(int status) {
    narm_context->api->exit(narm_context, status);
}

int narm_key_down(unsigned key) {
    return narm_context->keyboard->key_down(narm_context, key);
}

static inline int video_submit(unsigned command, const unsigned *args, unsigned count) {
    return narm_context->video->submit(narm_context, command, args, count);
}

int narm_half_present(void) {
    return video_submit(0, 0, 0);
}

int narm_half_clear(unsigned color) {
    return video_submit(1, &color, 1);
}

int narm_half_pixel(unsigned xy, unsigned color) {
    const unsigned args[] = {xy, color};
    return video_submit(2, args, 2);
}

int narm_half_fill_rect(int x, int y, int w, int h, unsigned color) {
    const unsigned args[] = {x, y, w, h, color};
    return video_submit(3, args, 5);
}

int narm_half_blit(int x, int y, int w, int h, const unsigned *texels) {
    const unsigned args[] = {x, y, w, h, (uintptr_t)texels};
    return video_submit(6, args, 5);
}

int narm_half_blit_masked(int x, int y, int w, int h, const unsigned *texels,
                         const unsigned *mask) {
    const unsigned args[] = {x, y, w, h, (uintptr_t)texels, (uintptr_t)mask};
    return video_submit(7, args, 6);
}

int narm_audio_ready(void) {
    return (narm_context->audio->status(narm_context) & 3) == 3;
}

int narm_audio_play_pcm(unsigned voice, const short *samples, unsigned frames,
                        unsigned rate, unsigned channels) {
    const unsigned args[] = {voice, (uintptr_t)samples, frames, rate, channels};
    return narm_context->audio->submit(narm_context, 1, args, 5);
}

int narm_audio_position(unsigned voice, unsigned *frame, unsigned *total,
                        unsigned *rate, unsigned *flags) {
    const unsigned args[] = {voice, (uintptr_t)frame, (uintptr_t)total, (uintptr_t)rate,
                             (uintptr_t)flags};
    return narm_context->audio->submit(narm_context, 6, args, 5);
}

int narm_file_create(const char *path, unsigned storage) {
    const unsigned args[] = {(uintptr_t)path, storage};
    return narm_context->file->submit(narm_context, 2, args, 2);
}

int narm_file_delete(const char *path, unsigned storage) {
    const unsigned args[] = {(uintptr_t)path, storage};
    return narm_context->file->submit(narm_context, 3, args, 2);
}

int narm_file_write(const char *path, const void *data, unsigned offset, unsigned count,
                    unsigned storage) {
    const unsigned args[] = {(uintptr_t)path, (uintptr_t)data, offset, count, storage};
    return narm_context->file->submit(narm_context, 7, args, 5);
}
