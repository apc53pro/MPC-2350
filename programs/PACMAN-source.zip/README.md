# PACMAN.narm

Copy `PACMAN.narm` to the storage you normally launch NARM games from. Press **T** for autopilot, **Space** to start manually, and the arrow keys or **WASD** to steer.

Autopilot chooses a direction at each tile center. As Pac-Man moves, it uses the same ghost update routines as the game to forecast upcoming turns. It searches up to 14 tile moves ahead, keeps eight candidate routes, and normally advances at most two search layers per game tick. The route score favors paths that reach pellets and give ghosts room.

The game advances to another maze after each clear. The 21 difficulty presets change the fruit and frightened time, with the last preset reused for subsequent mazes.

The shipped binary uses the same NARM 1.11 service interface as the synthesized-audio version of PACMAN. Arm GNU Toolchain 13.3 built the position-independent Thumb-2 code. To rebuild, provide the path to your toolchain's `bin` directory and to `Compiler_For_NARM/tools/narm_image.py` from the firmware project.

```text
python build_gcc.py --toolchain PATH_TO_ARM_GNU_BIN --image-tool PATH_TO_NARM_IMAGE_PY --output PACMAN.narm
```
