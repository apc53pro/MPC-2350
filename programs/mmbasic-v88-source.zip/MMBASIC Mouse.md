# MMBASIC v88 mouse support

Use `mmbasic.narm` with MPC-2350 firmware that provides NARM API 1.13 or later.
Replace the existing `mmbasic.narm` on the firmware filesystem and enter
`MMBASIC` at the system prompt. Keyboard editing still works when no mouse
is connected.

## Editor

- Left-click the source to place the caret. Drag to select text across lines.
  Shift-click extends the selection from the caret or its existing anchor.
  Typing replaces the selected text, and Backspace or Delete removes it.
- Use the wheel to scroll three lines per detent. During selection, hold the
  pointer at an edge to extend the selection while scrolling.
- Click Help, Save As, Load, Run, New, or REPL along the bottom. Save As has a
  clickable Save button. The help and run screens have a Return to Editor button.
- Click or drag in the text field at the REPL and in line prompts.

## BASIC

Selectors are case-insensitive quoted names. The live queries work in the REPL
and in stored programs.

| Selector | Result |
| --- | --- |
| `"X"`, `"Y"` | Current coordinates in the same 320×240 space used by `PIXEL` and `LINE`. Returns `-1` when input is unavailable. |
| `"CONNECTED"` | `1` when the firmware detects a mouse, otherwise `0`. |
| `"LEFT"`, `"RIGHT"`, `"MIDDLE"` | `1` while the button is down, otherwise `0`. |
| `"BUTTONS"` | Current button mask. Left is `1`, right `2`, middle `4`, back `8`, and forward `16`. |
| `"MOTION"` | Captures and clears the firmware's accumulated movement and wheel deltas. Returns `1` on a successful read. |
| `"DX"`, `"DY"`, `"WHEEL"` | Values captured by the last `"MOTION"` read. Positive motion is right or down. Wheel values are signed detents. |
| `"POLL"` | Reads the next event and returns its type mask, or `0` if the queue is empty. |
| `"EVENTX"`, `"EVENTY"` | Coordinates from the last `"POLL"`, or `-1` when no event was read. |
| `"EVENTDX"`, `"EVENTDY"`, `"EVENTWHEEL"` | Raw movement and wheel deltas for the last event. |
| `"EVENTBUTTONS"`, `"CHANGED"` | Button mask after the last event and the mask of buttons that changed. |

Event bits are movement `1`, press `2`, release `4`, wheel `8`, connect `16`,
disconnect `32`, and resync after overflow `64`. A report can combine bits.
Queued events retain quick clicks that happen between iterations of a running
program. The editor and line prompts use the queue while waiting for input.

```basic
DO
  E = MOUSE("POLL")
  IF E > 0 THEN PRINT E, MOUSE("EVENTX"), MOUSE("EVENTY")
  PAUSE 10
LOOP
```

## Rebuild

Use the current `Compiler_For_NARM` directory from the MPC-2350 project for
both the compiler and `narm.tch`. Keep the two source files together.

```powershell
& "$compilerDir/narmcc.exe" mmbasic_v88_narm.tc -I $compilerDir -O2 -o mmbasic.narm
```
